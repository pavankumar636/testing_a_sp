# Splunk Infrastructure - Indexer Terraform Module

This module will create a single Splunk Indexer instance within a ASG.

## Usage

```hcl
module "Indexer" {
  source             = "./modules/indexer"
  vpc_id             = "${var.vpc_id}"
  zones              = ["${var.zones}"]
  ami_id             = "${var.ami_id}"
  instance_type      = "${var.instance_types["indexer"]}"
  subnet_ids         = ["${var.subnet_ids}"]
  ebs_size           = "${var.indexer_ebs_size}"
  management_zone_id = "${var.management_zone_id}"  
  instance_count     = "2"
  puppet_master      = "foo.bar.aviva.co.uk"


  tags = {
    "foo" = "bar"
  }
}
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|:----:|:-----:|:-----:|
| ami_id | AMI ID which all Indexers will be run on | string | - | yes |
| ebs_size | Size (In GB) of the EBS Volume storing Indexer Data | string | `10` | no |
| infrastructure_prefix | Prefix for Resources (Security Groups, Route53 Records) | string | `` | no |
| instance_count | Number of instances to create | string | - | yes |
| instance_type | Type of EC2 Instances for the Indexers | string | - | yes |
| account_id | Account ID where the cluster will live | string | - | yes |
| management_sg | Management Security Group ID | string | - | yes |
| management_zone_id | ID of the Route53 Zone to create records for | string | - | yes |
| puppet_master | FQDN for Puppet Master | string | - | yes |
| subnet_ids | List of subnets | list | - | yes |
| tags | Tags to add to AWS Resources | map | - | yes |
| vpc_id | ID of the VPC which the Indexers will run on | string | - | yes |
| zones | The AWS Zones which the Indexers will span | list | `<list>` | no |
| trend_fqdn | FQDN for Trend | string | - | yes |
| proxy_fqdn | FQDN for Proxy | string | - | yes | 

## Outputs

| Name | Description |
|------|-------------|
| dns |  |