# Splunk Infrastructure - Universal Forwarder Terraform Module

This module will create a single Splunk Universal forwarder Server instance in ASG.

## Usage

```hcl
module "universal_forwarder" {
  source                  = "../../../modules/universal-forwarder"
  zones                   = ["${var.zones}"]
  win_ami_id              = "${var.win_ami_id}"
  instance_type           = "${var.instance_types["universal_forwarder"]}"
  subnet_ids              = ["${var.subnet_ids}"]
  infrastructure_prefix   = "${var.infrastructure_prefix}"
  tags                    = ["${var.tags}"]
  management_sg           = "${var.management_sg}"
  proxy_fqdn              = "${var.proxy_fqdn}"
  trend_fqdn              = "${var.trend_fqdn}"
  puppet_master           = "${var.puppet_master}"
  instance_number         = 0
  instance_security_group = "${aws_security_group.universal_forwarder.id}"
  ebs_size                = "${var.ebs_size["universal_forwarder"]}"
  ebs_type                = "${var.ebs_type}"
  sns_topic_arn           = "${module.sns.sns_topic_arn}"
  iam_instance_profile    = "${var.iam_instance_profile_uf}"
  domain_join_user        = "${var.domain_join_user}"
  domain_join_password    = "${var.domain_join_password}"
  ou_path                 = "${var.ou_path}"
  autoscaling_schedule    = ["${var.autoscaling_schedule}"]
  daemon_access_sg_ids    = "${aws_security_group.heavy_forwarder.id}"
  environment             = "${var.environment}"
  vault_addr              = "Vault_addr" 
  vault_role              = "splunk_universal_forwarder"
  az_count                = 2
  hf_url                  = "hf_url"
  }
```