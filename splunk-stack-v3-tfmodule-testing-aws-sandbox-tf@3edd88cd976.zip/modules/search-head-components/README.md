# Splunk Infrastructure - Search Head Terraform Module

This module will create a single Splunk Search Head instance within a ASG.

## Usage

```hcl
module "utility_server" {
  source             = "./modules/search-head"
  vpc_id             = "${var.vpc_id}"
  zones              = ["${var.zones}"]
  ami_id             = "${var.ami_id}"
  instance_type      = "${var.instance_types["search_head"]}"
  subnet_ids         = ["${var.subnet_ids}"]
  management_zone_id = "${var.management_zone_id}"
  instance_count     = "2"
  puppet_master      = "foo.bar.aviva.co.uk"

  tags = {
    "foo" = "bar"
  }
}
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|:----:|:-----:|:-----:|
| KV\_store\_sg\_ids | the security group ids that should be able to access the key value store. | list | n/a | yes |
| KV\_store\_sg\_length | The number of security group ids for accessing the search head KV store, required because terraform count cannot handle computed values. | string | n/a | yes |
| account\_id | Account ID where the instances will be created | string | n/a | yes |
| ami\_id | AMI ID which all Search Heads will be run on | string | n/a | yes |
| daemon\_access\_sg\_ids | The security group ids that should be able to access the splunk daemon. | list | n/a | yes |
| daemon\_access\_sg\_length | The number of security group ids for accessing the splunk daemon, required because terraform count cannot handle computed values. | string | n/a | yes |
| ebs\_piops | Provisioned IOPS for data EBS Volume | string | `"500"` | no |
| ebs\_size | Size (In GB) of the EBS Volume | string | `"15"` | no |
| infrastructure\_prefix | Prefix for Resources (Security Groups, Route53 Records) | string | `""` | no |
| instance\_count | Number of instances to create | string | n/a | yes |
| instance\_security\_group | The security group for the search head instances. | string | n/a | yes |
| instance\_type | Type of EC2 Instances for the Search Heads | string | n/a | yes |
| management\_sg | Management Security Group ID | string | n/a | yes |
| management\_zone\_id | ID of the Route53 Zone to create records for | string | n/a | yes |
| proxy\_fqdn | FQDN for Proxy | string | n/a | yes |
| puppet\_master | FQDN for Puppet Master | string | n/a | yes |
| splunk\_ssl\_arn | ARN for Splunk SSL Certificate | string | n/a | yes |
| subnet\_ids | List of subnets | list | n/a | yes |
| tags | Tags to add to AWS Resources | map | n/a | yes |
| trend\_fqdn | FQDN for trend | string | n/a | yes |
| vpc\_id | ID of the VPC which the Search Heads will run on | string | n/a | yes |
| zones | The AWS Zones which the Search Heads will span | list | `<list>` | no |

## Outputs

| Name | Description |
|------|-------------|
| search\_heads\_alb\_fqdn |  |
| security\_group\_ids |  |