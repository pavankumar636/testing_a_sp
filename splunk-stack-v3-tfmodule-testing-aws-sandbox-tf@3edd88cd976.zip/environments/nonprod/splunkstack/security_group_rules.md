# All instances
All instances will have the standard management ingress rules added to them, this enables:
1. Active Directory
2. Trend
3. Nexpose

They will also need port 8140 open to the puppet master.
SSH from 10.0.0.0/8 is also enabled.

# Utility instances
1. Any Splunk instance other than the utility instances can access the utility instances daemon
2. The GUI can be accessed through the load balancer for the utility instances
3. The utility instance can access its own key value store

## Ingress
| protocol | port | source | purpose |
| ------ | ------ | ------ | ------ |
| tcp | 8089 | indexers | indexer access to the splunk daemon |
| tcp | 8089 | search heads | search head access to the splunk daemon |
| tcp | 8089 | heavy forwarders | heavy forwarder access to the splunk daemon |
| tcp | 8000 | Utility load balancer | load balancer access to the GUI |
| tcp | 8191 | self | Utility access to the key value store |


## Egress
Anywhere within 10.0.0.0/8

# Search Head
1. The GUI can be accessed through the load balancer for the search head instances
2. Any Splunk instance other than the search head instances can access the search head instances daemon
3. The utility instances and the search head instances can access the search heads key value store
4. The search heads can access the replication port

## Ingress
| protocol | port | source | purpose |
| ------ | ------ | ------ | ------ |
| tcp | 8000 | search head load balancer | load balancer access to the GUI |
| tcp | 8089 | indexers | indexer access to the splunk daemon |
| tcp | 8089 | utility box | utility box access to the splunk daemon |
| tcp | 8089 | heavy forwarders | heavy forwarder access to the splunk daemon |
| tcp | 8089 | self | self access to the splunk daemon |
| tcp | 8191 | utility box | utility box access to the KV store |
| tcp | 8191 | search head | search head access to the KV store |
| tcp | 9887 | search head | search head access for replication |


## Egress
Anywhere within 10.0.0.0/8

# Indexer
1. Any Splunk instance other than the utility instances can access the indexer instances daemon
2. The indexer instances can access the replication port
3. The heavy forwarder instances can access the data forwarding port
## Ingress
| protocol | port | source | purpose |
| ------ | ------ | ------ | ------ |
| tcp | 8089 | search heads | search head access to the splunk daemon |
| tcp | 8089 | heavy forwarders | heavy forwarder access to the splunk daemon |
| tcp | 8089 | utility instances | utility instances access to the splunk daemon |
| tcp | 8089 | indexers | indexer access to the splunk daemon |
| tcp | 9887 | indexers | indexer access for replication |
| tcp | 9997 | heavy forwarder| heavy forwarder access to forward to the indexer |
| tcp | 9997 | search heads | search head access to forward to the indexer |
| tcp | 9997 | utility instances | utility access to forward to the indexer |

## Egress
Anywhere within 10.0.0.0/8

# Heavy Forwarder
1. Any Splunk instance other than the heavy forwarder can access the indexer instances daemon
2. The heavy forwarder instances can access the key value store
3. Kinesis Firehose can access the http event collector (HEC)

## Ingress
| protocol | port | source | purpose |
| ------ | ------ | ------ | ------ |
| tcp | 8088 | kinesis firehose streams | Allows kinesis firehose to access the event collector |
| tcp | 8089 | indexers | indexer access to the splunk daemon |
| tcp | 8089 | utility box | utility box access to the splunk daemon |
| tcp | 8089 | search heads | search head access to the splunk daemon |
| tcp | 8089 | self | self access to the splunk daemon |
| tcp | 8191 | self | self access to the key value store |


## Egress
Anywhere within 10.0.0.0/8
