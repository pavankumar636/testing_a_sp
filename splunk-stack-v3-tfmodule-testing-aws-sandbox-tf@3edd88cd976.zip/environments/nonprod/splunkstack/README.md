# Splunk Stack v2 Terraform Module

This module will create the initial Splunk infrastructure, spinning up instances dedicated to Heavy Forwarder, Indexers, Search Heads and Utility Server.

## Module Input Variables

| Name | Description | Type | Default | Required |
|------|-------------|:----:|:-----:|:-----:|
| account\_id | Account ID where the cluster will live | string | n/a | yes |
| ami\_id | AMI ID which all Splunk instances will be run on | string | n/a | yes |
| assume\_role\_arns | List of Account ARN's to permit assuming | list | n/a | yes |
| ebs\_piops | IOPS for Volume at /opt/splunk | map | `<map>` | no |
| ebs\_size | EBS Volume Sizes for /opt/splunk | map | `<map>` | no |
| hec\_token | Splunk HEC Token | string | n/a | yes |
| indexer\_ebs\_piops | Provisioned IOPS for indexer EBS volumes. | string | `"500"` | no |
| indexer\_ebs\_size | Size of the Indexers EBS Volume | string | `"10"` | no |
| infrastructure\_prefix | Prefix for Resources (Security Groups, Route53 Records) | string | `""` | no |
| instance\_count | Number of Splunk instances | map | `<map>` | no |
| instance\_types | Type of EC2 Instances for each Splunk Instance type | map | `<map>` | no |
| management\_sg | Management account Security Group | string | `""` | no |
| management\_zone\_id | ID of the Route53 Zone to create records for | string | n/a | yes |
| proxy\_fqdn | FQDN for Proxy | string | n/a | yes |
| public\_management\_zone\_id | ID of the Route53 Zone to create public records for | string | n/a | yes |
| public\_ssl\_arn | ARN for Public SSL Certificate | string | n/a | yes |
| public\_subnet\_ids | List of Public subnets | list | n/a | yes |
| puppet\_master | FQDN for Puppet Master | string | n/a | yes |
| splunk\_ssl\_arn | ARN for Splunk SSL Certificate | string | n/a | yes |
| subnet\_ids | List of subnets | list | n/a | yes |
| tags | Tags to add to AWS Resources | map | n/a | yes |
| trend\_fqdn | FQDN for trend | string | n/a | yes |
| vpc\_id | ID of the VPC which the Splunk Platform will run on | string | n/a | yes |
| zones | The AWS Zones which the Splunk Platform will span | list | `<list>` | no |

## Usage

```hcl
module "splunk" {
  source = "splunk-infrastructure"

  zones                 = ["eu-west-1a", "eu-west-1b"]
  vpc_id                = "121312312"
  subnet_ids            = ["s-ase23e23e"]
  ami_id                = "ami-12312"
  management_zone_id    = "sqe3reefef"
  public_management_zone_id    = "sqe3reefeb"
  infrastructure_prefix = "foo-"
  puppet_master         = "foo.bar.aviva.co.uk"
  trend_fqdn            = "foo.bar.aviva.co.uk"
  proxy_fqdn            = "foo.bar.aviva.co.uk"
  hec_token             = "51D4DA16-C61B-4F5F-8EC7-ED4301342A4A"
  
  tags = {
    "foo" = "bar"
  }

  instance_types = {
    heavy_forwarder = "c4.2xlarge"
    indexer         = "c4.4xlarge"
    search_head     = "c4.4xlarge"
    utility_server  = "c4.2xlarge"
  }
  
  instance_count = {
    heavy_forwarder = "2"
    indexer         = "4"
    search_head     = "2"
  }
}
```

## Testing

N/A

## Linting & Formatting

Run [tflint](https://github.com/wata727/tflint) and [terraform fmt](https://www.terraform.io/docs/commands/fmt.html) to analyse code for potential errors and verify adherence to [style guide](https://confluence.aviva.co.uk/display/CLOUDHOST/Style+Guide).

## Dependencies

### External

| Module Name | Requirement                                 |
|-------------|---------------------------------------------|
| management-infra-tfmodule  | VPC and Subnet Creation |

### Internal

* Terraform Version 0.10.7

## Outputs

| Name | Description |
|------|-------------|
| aws\_sqs\_queue\_id |  |
| kinesis\_firehose\_alb\_fqdn |  |
| search\_heads\_alb\_fqdn |  |
| utility\_server\_alb\_fqdn |  |

## Known Issues/Limitations

N/A