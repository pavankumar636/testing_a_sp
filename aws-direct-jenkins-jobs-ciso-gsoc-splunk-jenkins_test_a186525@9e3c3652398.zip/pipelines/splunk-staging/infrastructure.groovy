/*
* Deploy Splunk staging instance
*
* Jenkins Environment Variables:
*   AWS_MANAGEMENT_PROXY
*   AWS_DEFAULT_REGION
*
* Jenkins Job Parameters:
*   environment
*   gitBranch
*   terraformApplyPlan
*   infrastructure_prefix
*   approvers
*/

def bucket_key = "client-ciso/${infrastructure_prefix}splunk-staging.tfstate"

node ('deploy-client') {

  env.http_proxy=env.AWS_MANAGEMENT_PROXY
  env.https_proxy=env.AWS_MANAGEMENT_PROXY
  env.no_proxy='169.254.169.254,avivacloud.com,stash.aviva.co.uk'
  env.GIT_ASKPASS="$WORKSPACE/git_askpass.sh"
  env.TF_VAR_infrastructure_prefix="${infrastructure_prefix}"

  stage ('Checkout'){
    deleteDir()

    checkout([$class: 'GitSCM', branches: [[name: gitBranch]], userRemoteConfigs: [[credentialsId: "bitbucket", url: "https://stash.aviva.co.uk/scm/gcisoseceng/splunk-staging.git"]]])
 
    withCredentials([usernamePassword(credentialsId: "bitbucket", usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD')]){
    }
  }

  stage ('Initialise'){
    dir("environments/${environment}") {
      sh "terraform version"
      sh "terraform init -backend-config='key=${bucket_key}' -input=false "
    }
  }

  stage ('Plan'){
    dir("environments/${environment}") {
        sh "terraform get --update"
        if (action == 'create') {
          sh "terraform plan -out=tfplan"
        } else if (action == 'destroy') {
          sh "terraform plan -destroy -out=tfplan"
        }
        stash include: 'tfplan', name: 'tfplan'
    }
  }
}

if (terraformApplyPlan == 'true') {
  stage ('Apply Approve') {
    timeout(time:5, unit:'DAYS') {
        input id: 'ApproveDeployment', message:'Approve deployment?', ok: 'Approve', submitter: approvers
    }
  }
  
  node ('deploy-client') {
    stage ('Apply'){
      dir("environments/${environment}") {
        unstash 'tfplan'
        sh "terraform apply  -input=false -no-color tfplan"
        sh 'rm tfplan'
      }
    }
  }
}
