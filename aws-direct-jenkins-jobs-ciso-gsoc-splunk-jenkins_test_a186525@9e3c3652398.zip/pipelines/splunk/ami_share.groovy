import java.util.regex.*

gitCreds              = 'bitbucket'

node ('build-app-tfv11') {

  env.http_proxy=env.AWS_MANAGEMENT_PROXY
  env.https_proxy=env.AWS_MANAGEMENT_PROXY
  env.no_proxy='169.254.169.254,aws-euw1-services.com,avivacloud.com,compute.internal'

  //Checkout
  stage ('Checkout'){
    deleteDir()
    checkout([$class: 'GitSCM', branches: [[name: gitBranch]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'SubmoduleOption', disableSubmodules: false, parentCredentials: true, recursiveSubmodules: true, reference: '', trackingSubmodules: false]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: gitCreds, url: gitUrl]]])
  }

  // Sharing of AMI to client workload accounts
  if (accountsShare != ''){
    stage ('Share AMI'){
      shareAmi(sourceAmi, sourceAccount, accountsShare)
    }
  }
}


// Share an AMI with a list of accounts
def shareAmi(sourceAmi, awsAccount, awsAccountList) {
  def roleArn = "arn:aws:iam::${awsAccount}:role/baker"
  echo "Sharing AMI ${sourceAmi} from ${awsAccount} with ${awsAccountList}"
  sh "~/bin/rake image:share['${roleArn}','${sourceAmi}','${awsAccountList}']"
  echo "Shared AMI ${sourceAmi} from ${awsAccount} with ${awsAccountList}"
}