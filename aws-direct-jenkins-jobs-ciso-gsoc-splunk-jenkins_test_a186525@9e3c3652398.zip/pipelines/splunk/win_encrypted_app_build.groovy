/*
* Build encrypted AMI
*
* Jenkins Global Environment Variables:
*   AWS_MANAGEMENT_PROXY
*   AWS_DEFAULT_REGION
*
* Jenkins Job Parameters:
*   gitCreds
*   gitUrl
*   gitBranch
*   packerDir
*   packerTemplateFile
*   packerVarFile
*   packerLogLevel
*   managementAccount
*   accountsShare
*   accountsEncrypt
*   terraformDir
*   terraformEnvironment
*   terraformLogLevel
*   domainName
*   ouPath
*   serverspecRole
*   cisArchive
*   cisBenchmark
*   cisProfile
*   deleteUnencryptedAmi
*   environment
*   bakery_proxy_dns_name
*   wsus_dns_name
*/

def awsDefaultRegion   = 'eu-west-1'

def sourceAmi
def sourceAmiName
def hostname
def accountsArray

node ('build-app-tfv11') {

  env.http_proxy       = env.AWS_MANAGEMENT_PROXY
  env.https_proxy      = env.AWS_MANAGEMENT_PROXY
  env.no_proxy         ='169.254.169.254,avivacloud.com,compute.internal,aws-euw1-services.com,binaries.avivagroup.com'
  
  env.TEMP_ADMIN_PASS  = sh(script: '/usr/bin/openssl rand -base64 7', returnStdout: true).trim()

  // Checkout git repository on local Jenkins platform
  stage ('Checkout') {
    deleteDir()
    checkout([$class: 'GitSCM', branches: [[name: gitBranch]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'SubmoduleOption', disableSubmodules: false, parentCredentials: true, recursiveSubmodules: true, reference: '', trackingSubmodules: false]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: gitCreds, url: gitUrl]]])
  }

  // Bake Application AMI from Golden AMI
  stage ('Build AMI') {
    try {
		wrap([$class: 'MaskPasswordsBuildWrapper']) {
			sourceAmi = buildAmi(managementAccount, packerDir, packerVarFile, packerTemplateFile, packerLogLevel, environment, arti_user, arti_pass, bakery_proxy_dns_name, wsus_dns_name)
		}
    } catch (Exception e) {
        //if buildAmi fails we will catch the exception here and kill anu un-terminated instances
        destroyPackerInstance()
        error("Building AMI failed")
    }
    sourceAmiName = getAmiName(sourceAmi)
  }

  // Run CISCAT scan on test instance launched from baked ami
  stage ('Test AMI') {
    try {
        hostname = startTestInstance(managementAccount, sourceAmi, terraformDir, terraformEnvironment, terraformLogLevel, domainName, ouPath)
        echo "Sleeping for 20 minutes to allow the instance to start and join the domain"
        sleep time: 20, unit: 'MINUTES'
        runServerspec(hostname, serverspecRole)
        runCisCat(hostname, cisArchive, cisBenchmark, cisProfile)
    } catch (Exception ex) {
        error("Testing for AMI failed")
    } finally {
    destroyTestInstance(managementAccount, sourceAmi, terraformEnvironment, terraformLogLevel, domainName, ouPath)
	}
    tagAmi(managementAccount, sourceAmi,'Lifecycle=available')
  }

  // Sharing of AMI to client workload accounts
  if (accountsShare !='') {
    stage ('Share AMI') {
      shareAmi(sourceAmi, managementAccount, accountsShare)
    }
  }

  // Build and encrypt AMI in shared account
  if (accountsEncrypt !='') {
    accountsArray = convertStringToList(accountsEncrypt)
    for (int i = 0; i < accountsArray.size(); i++) {
      account = accountsArray.get(i)
      stage ("Encrypt AMI in ${account}") {
        createEncryptedAmi(managementAccount, account, sourceAmi, sourceAmiName, packerDir, packerVarFile, packerTemplateFile, packerLogLevel)
      }
    }
  }

  // Delete unencrypted source AMI if its not an intermediate AMI
  if (deleteUnencryptedAmi == 'yes') {
    stage ('Delete Unencrypted AMI') {
      deleteAmi(managementAccount, sourceAmi)
    }
  }
}


// Helper Functions

// Build Windows AMI
def buildAmi(awsAccount, packerDir, packerVarFile, packerTemplateFile, packerLogLevel, environment, arti_user, arti_pass, bakery_proxy_dns_name, wsus_dns_name) {
  def awsAmi
  def roleArn = "arn:aws:iam::${awsAccount}:role/baker"

  echo "Building AMI in ${awsAccount}"

  sh "~/bin/rake environment:app_variables_file['${roleArn}','${packerDir}/${packerVarFile}']"

  dir(packerDir) {
    env.PACKER_LOG = packerLogLevel
	withCredentials([usernamePassword(credentialsId: 'bitbucket', passwordVariable: 'STASH_PASS', usernameVariable: 'STASH_USER')]){
      sh "packer validate -var-file=${packerVarFile} -var environment=${environment} -var arti_user=${arti_user} -var arti_pass=${arti_pass} -var bakery_proxy_dns_name=${bakery_proxy_dns_name} -var wsus_dns_name=${wsus_dns_name} ${packerTemplateFile}"
      sh "set -o pipefail; packer build -machine-readable -var-file=${packerVarFile} -var environment=${environment} -var arti_user=${arti_user} -var arti_pass=${arti_pass} -var bakery_proxy_dns_name=${bakery_proxy_dns_name} -var wsus_dns_name=${wsus_dns_name} ${packerTemplateFile} | tee packer-build.txt"
      awsAmi = sh (script: "egrep --only-matching --regexp='ami-.{17}' packer-build.txt | tail -1", returnStdout: true).trim()
	}
  }

  // Tag AMI
  awsAmiSourceAmi = getAmiTagValue(awsAmi, 'SourceAmi')
  echo "$awsAmiSourceAmi"
  foundationAmi = getAmiTagValue(awsAmiSourceAmi, 'FoundationAmi')
  sh "~/bin/rake image:tag['${roleArn}','${awsAmi}','Encrypted=false','FoundationAmi=${foundationAmi}','Jenkins=${JOB_NAME}-${BUILD_NUMBER}','Lifecycle=build']"
  sh "~/bin/rake image:tag['${roleArn}','${awsAmi}','Encrypted=false','Jenkins=${JOB_NAME}-${BUILD_NUMBER}','Lifecycle=build']"
  echo "Built AMI ${awsAmi}"

  return awsAmi
}

//Terminate packer instance

def destroyPackerInstance() {
  dir(packerDir){
   instanceId = sh (script: "egrep --only-matching --regexp='i-(\\w){17}' packer-build.txt | head -1", returnStdout: true).trim()
   echo "Destroying instance ${instanceId}"
   sh "aws ec2 terminate-instances --instance-ids ${instanceId}"
  }
}

// Share an AMI with the list of accounts
def shareAmi(sourceAmi, awsAccount, awsAccountList) {
  def roleArn = "arn:aws:iam::${awsAccount}:role/baker"
  sh "~/bin/rake image:share['${roleArn}','${sourceAmi}','${awsAccountList}']"
  echo "Shared AMI ${sourceAmi} from ${awsAccount} with ${awsAccountList}"
}

// Create an encrypted AMI in a target account from a unencrypted source AMI
def createEncryptedAmi(managementAccount, awsAccount, sourceAmi, sourceAmiName, packerDir, packerVarFile, packerTemplateFile, packerLogLevel) {
  def encryptedAmi
  def amiToEncrypt
  def roleArn = "arn:aws:iam::${awsAccount}:role/baker"
  def hsn_tag = getAmiTagValue(sourceAmi, 'HSN')
  def owner_tag = getAmiTagValue(sourceAmi, 'Owner')
  def cost_centre_tag = getAmiTagValue(sourceAmi, 'Costcentre_Projectcode')

  echo "Building encrypted AMI in ${awsAccount} from ${sourceAmi} ${sourceAmiName}"

  // Create a copy of the source AMI unless you are in the account it was created in
  if (managementAccount != awsAccount) {
    sh "~/bin/rake environment:variables_file['${roleArn}','${packerDir}/${awsAccount}_${packerVarFile}']"
    sh "~/bin/rake environment:packer_copy_win_2016_template['${roleArn}','copy-${sourceAmiName}','${sourceAmi}','${owner_tag}','${cost_centre_tag}','${hsn_tag}','${packerDir}/${awsAccount}_${packerVarFile}','${packerDir}/${awsAccount}_${packerTemplateFile}','${awsAccount}']"

    dir(packerDir) {
      env.PACKER_LOG = packerLogLevel
      sh "packer validate ${awsAccount}_${packerTemplateFile}"
      sh "set -o pipefail; packer build -machine-readable ${awsAccount}_${packerTemplateFile} | tee ${awsAccount}-packer-build.txt"
      amiToEncrypt = sh (script: "egrep --only-matching --regexp='ami-.{17}' ${awsAccount}-packer-build.txt | tail -1", returnStdout: true).trim()
    }
  }
  else {
    amiToEncrypt = sourceAmi
  }

  // Encrypt copied AMI
  encryptedAmi = encryptAmi(amiToEncrypt, awsAccount)

  // Delete copied AMI if one was created
  if (managementAccount != awsAccount) {
    sh "~/bin/rake image:delete['${roleArn}','${amiToEncrypt}']"
  }

  // Tag AMI
  sourceAmiNameTag = getAmiTagValue(sourceAmi, 'Name')
  sourceAmiSourceTag = getAmiTagValue(sourceAmi, 'SourceAmi')
  sh "~/bin/rake image:tag['${roleArn}','${encryptedAmi}','Jenkins=${JOB_NAME}-${BUILD_NUMBER}','Lifecycle=authorised','Name=${sourceAmiNameTag}-encrypted','SourceAmi=${sourceAmiSourceTag}']"
}

// Encrypt AMI in a given account
def encryptAmi(sourceAmi, awsAccount){
  def roleArn = "arn:aws:iam::${awsAccount}:role/baker"

  echo "Encrypting AMI ${sourceAmi} in ${awsAccount}"
  sh "set -o pipefail; ~/bin/rake image:encrypt['${roleArn}','${sourceAmi}'] | tee ${awsAccount}-image-encrypt.txt"
  encryptedAmi = sh (script: "egrep --only-matching --regexp='ami-.{17}' ${awsAccount}-image-encrypt.txt | tail -1", returnStdout: true).trim()
  echo "Created encrypted AMI ${encryptedAmi}"

  return encryptedAmi
}

// Start Terraform test instance
def startTestInstance(awsAccount, awsAmi, terraformDir, environment, terraformLogLevel, domainName, ouPath) {
  def hostname

  echo "Starting test instance using ${awsAmi} in ${environment} ${awsAccount}"

  env.TF_VAR_image_id          = awsAmi
  env.TF_VAR_aws_provider_role = "arn:aws:iam::${awsAccount}:role/tester-baker"
  env.TF_VAR_environment       = environment
  env.TF_LOG                   = terraformLogLevel

  dir(terraformDir) {
     withCredentials([
        usernamePassword(credentialsId: 'jenkins-testing-user', passwordVariable: 'WIN_TESTING_PASSWORD', usernameVariable: 'WIN_TESTING_USERNAME'),
        usernamePassword(credentialsId: 'win-domain-join', passwordVariable: 'DOMAIN_JOIN_PASSWORD', usernameVariable: 'DOMAIN_JOIN_USER')
     ]) {
	   sh "terraform --version"
	   sh "terraform init -no-color -input=false"
       sh "terraform plan -out=tfplan -var 'test_user_password=${WIN_TESTING_PASSWORD}' -var 'test_user=${WIN_TESTING_USERNAME}' \
         -var 'domain_join_user=${DOMAIN_JOIN_USER}' -var 'domain_join_password=${DOMAIN_JOIN_PASSWORD}' \
         -var 'domain=${domainName}' -var 'ou_path=${ouPath}'"
       sh "terraform apply -input=false tfplan"
    }
    hostname = sh (script: "terraform output hostname", returnStdout: true).trim()
  }

  return hostname
}

// Terminate Terraform test instance
def destroyTestInstance(awsAccount, awsAmi, environment, terraformLogLevel, domainName, ouPath){
  echo "Destroying test instance ${awsAmi} in ${environment} ${awsAccount}"

  env.TF_VAR_image_id          = awsAmi
  env.TF_VAR_aws_provider_role = "arn:aws:iam::${awsAccount}:role/tester-baker"
  env.TF_VAR_environment       = environment
  env.TF_LOG                   = terraformLogLevel

  dir(terraformDir) {
    withCredentials([
      usernamePassword(credentialsId: 'jenkins-testing-user', passwordVariable: 'WIN_TESTING_PASSWORD', usernameVariable: 'WIN_TESTING_USERNAME'),
      usernamePassword(credentialsId: 'win-domain-join', passwordVariable: 'DOMAIN_JOIN_PASSWORD', usernameVariable: 'DOMAIN_JOIN_USER')
    ]) {
      sh "terraform destroy -var 'test_user_password=${WIN_TESTING_PASSWORD}' -var 'test_user=${WIN_TESTING_USERNAME}' \
        -var 'domain_join_user=${DOMAIN_JOIN_USER}' -var 'domain_join_password=${DOMAIN_JOIN_PASSWORD}' \
        -var 'domain=${domainName}' -var 'ou_path=${ouPath}' -force"
      }
  }
}

// Run ServerSpec Tests
def runServerspec(hostname, serverspecRole){
  echo "Running ServerSpec ${serverspecRole} on ${hostname}"

  env.TARGET_HOST = hostname

  withCredentials([usernamePassword(credentialsId: 'jenkins-testing-user', passwordVariable: 'WIN_TESTING_PASSWORD', usernameVariable: 'WIN_TESTING_USERNAME')]) {
    env.WIN_TESTING_USERNAME = WIN_TESTING_USERNAME
    env.WIN_TESTING_PASSWORD = WIN_TESTING_PASSWORD
    sh "~/bin/rake ${serverspecRole}"
  }
  archive 'serverspec.*'
}

// Run cis-cat Tests
def runCisCat(hostname, cisArchive, cisBenchmark, cisProfile) {
  echo "Running cis-cat on ${hostname}"

  options = '--accept-terms --status'

  withCredentials([usernamePassword(credentialsId: 'jenkins-testing-user', passwordVariable: 'WIN_TESTING_PASSWORD', usernameVariable: 'WIN_TESTING_USERNAME')]) {
    sh "~/bin/rake test:win_cis_cat['${hostname}','${WIN_TESTING_USERNAME}','${WIN_TESTING_PASSWORD}','${cisBenchmark}','${cisProfile}','${options}']"
  }
  archive 'cis-cat-report.*'
}

// Deletes an AMI name from a given account
def deleteAmi(awsAccount, awsAmi) {
  def roleArn = "arn:aws:iam::${awsAccount}:role/baker"
  echo "Deleting AMI ${awsAmi} in ${awsAccount}"
  sh "~/bin/rake image:delete['${roleArn}','${awsAmi}']"
}

// Retrieves AMI name from current account
def getAmiName(sourceAmi) {
  amiName = sh (script: "aws ec2 describe-images --image-ids ${sourceAmi} --query 'Images[*].{Name:Name}' --output text", returnStdout: true).trim()
  echo "AMI name ${amiName}"
  return amiName
}

// Tags an AMI
def tagAmi(awsAccount, awsAmi, tag) {
  def roleArn = "arn:aws:iam::${awsAccount}:role/baker"
  echo "Tagging AMI ${awsAmi} in ${awsAccount} with ${tag}"
  sh "~/bin/rake image:tag['${roleArn}','${awsAmi}','${tag}']"
}

// Returns the value of a tag of an AMI
def getAmiTagValue(awsAmi, tagName) {
  tagValue = sh(script: "aws ec2 describe-images --image-ids ${awsAmi} --query \"Images[*].Tags[?Key=='${tagName}'].Value\" --output text", returnStdout: true).trim()
  echo "AMI ${awsAmi} tag ${tagName} ${tagValue}"
  return tagValue
}

@NonCPS
def convertStringToList(inputString){
  List<String> items = Arrays.asList(inputString.split("\\s*,\\s*"));
  return items
}