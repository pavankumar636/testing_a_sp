/*
* Deploy an application to a single environment
*
* Jenkins Environment Variables:
*   AWS_MANAGEMENT_PROXY
*   AWS_DEFAULT_REGION
*
* Jenkins Job Parameters:
*   gitUrl
*   gitBranch
*   gitCreds
*   terraformBucket
*   terraformKey
*   terraformApplyPlan
*   terraformaccounttype
*   location
*/

import groovy.json.JsonSlurper

node ('deploy-client') {

  // Global Variables declaration

  terraformBucket = "aviva-${terraformaccounttype}-tfstate"
  terraformPrefix = "client-ciso/puppet-master"

  def terraformdir_SharedStorage      = "stacks/shared/s3"
  def terraformdir_SharedKMS          = "stacks/shared/kms"
  def terraformdir_SharedNetwork      = "stacks/shared/network"
  def terraformdir_SharedSNS          = "stacks/shared/sns"
  def terraformdir_SharedNLB          = "stacks/shared/nlb"

  def terraformdir_DNS                = "stacks/frontend/dns"
  def terraformdir_ASG                = "stacks/frontend/main"

  stage('Initiating'){
    echo "Cleaning up workspace"
    deleteDir()
    WORKSPACE = pwd()
    sh("rm -rf ${WORKSPACE}/*")

    echo "Preparing Environment"
    env.http_proxy=env.AWS_MANAGEMENT_PROXY
    env.https_proxy=env.AWS_MANAGEMENT_PROXY
    env.no_proxy='169.254.169.254,avivacloud.com,127.0.0.1,localhost'


    writeFile(file: "git-askpass-${BUILD_TAG}", text: "#!/bin/bash\ncase \"\$1\" in\nUsername*) echo \"\${STASH_USERNAME}\" ;;\nPassword*) echo \"\${STASH_PASSWORD}\" ;;\nesac")
    sh "chmod a+x git-askpass-${BUILD_TAG}"

  }
  def all_stacks_2d_list = []

  //shared stack
  all_stacks_2d_list.add([tfPlanSharedStorage, terraformdir_SharedStorage, 'Storage Stack', 'storage'])
  all_stacks_2d_list.add([tfPlanSharedKMS, terraformdir_SharedKMS, 'Encryption Stack', 'kms'])
  all_stacks_2d_list.add([tfPlanSharedNetwork, terraformdir_SharedNetwork, 'Network Stack for application server', 'sg_app'])
  all_stacks_2d_list.add([tfPlanSharedSNS, terraformdir_SharedSNS, 'SNS Stack', 'sns'])
  all_stacks_2d_list.add([tfPlanSharedNLB, terraformdir_SharedNLB, "NLB Stack", 'nlb'])

  all_stacks_2d_list.add([tfPlanASG, terraformdir_ASG, 'ASG for Puppet master', 'asg'])
  all_stacks_2d_list.add([tfPlanDNS, terraformdir_DNS, 'DNS for Puppet master', 'dns'])

  dir(terraformenv) {
    stage ('Checkout') {
        git_checkout()
    }

    for (stack_list in all_stacks_2d_list) {

	     if (stack_list[0] == 'true') {
        run_terraform(stack_list[1], stack_list[2], stack_list[3])
      }
    }

  }
  stage('Tidying up'){
    echo "Tidying up workspace"
    // unsetting env variables that match TF_VAR_
    sh "unset \$(env | grep TF_VAR_ |awk -F'=' '{print \$1}')"
  }
}

def git_checkout() {
    checkout([$class: 'GitSCM', branches: [[name: gitBranch]], clearWorkspace: true, doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'SubmoduleOption', disableSubmodules: false, parentCredentials: true, recursiveSubmodules: true, reference: '', trackingSubmodules: false]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: gitCreds, url: gitUrl]]])
}

def terraform_init(terraformBucket,terraformPrefix,terraformkey) {
  withEnv(["GIT_ASKPASS=${WORKSPACE}/git-askpass-${BUILD_TAG}"]) {
    withCredentials([usernamePassword(credentialsId: gitCreds, passwordVariable: 'STASH_PASSWORD', usernameVariable: 'STASH_USERNAME')]) {
      sh "terraform init -no-color -force-copy -input=false -upgrade=true -backend=true -backend-config='bucket=${terraformBucket}' -backend-config='workspace_key_prefix=${terraformPrefix}' -backend-config='key=${terraformkey}'"
      sh "terraform get -no-color -update=true"
		}
	}
}

def terraform_plan(workspace,env_tfvars) {
    sh "terraform workspace select ${workspace} || terraform workspace new ${workspace}"
    sh "terraform plan -no-color -out=tfplan -input=false -var-file=${env_tfvars}"
}

def terraform_apply() {
	sh "terraform apply -input=false -no-color tfplan"
}

def run_terraform(terraformdir,stage_description,tfstate_key) {
  dir(terraformdir) {
    stage ('Terraform Remote State') {
      print ("### Terraform Remote State for ${stage_description} ###")
      terraformKey = "${tfstate_key}.tfstate"
      terraform_init(terraformBucket, terraformPrefix, terraformKey)
    }
    stage ('Terraform Plan') {
      print ("### Terraform Plan for ${stage_description} ###")
      env_tfvars = "${WORKSPACE}/${terraformenv}/environments/${terraformenv}.tfvars"
      terraform_plan(terraformenv, env_tfvars)
    }
    if (terraformApplyPlan == 'true') {
      stage ('Terraform Apply') {
        timeout(5) {
          input id: 'ApproveDeployment', message:'Approve deployment?', ok: 'Approve', submitter: approvers
        }
        print ("### Terraform Apply for ${stage_description} ###")
        terraform_apply()
      }
    }
    else {
      stage ('Terraform Apply') {
        print ("### Skip Terraform Apply for ${stage_description} ###")
      }
    }
  }
}