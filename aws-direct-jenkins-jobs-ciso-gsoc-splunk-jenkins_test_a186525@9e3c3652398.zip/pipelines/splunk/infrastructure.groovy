/*
* Deploy an application to a single environment
*
* Jenkins Environment Variables:
*   AWS_MANAGEMENT_PROXY
*   AWS_DEFAULT_REGION
*
* Jenkins Job Parameters:
*   environment
*   gitBranch
*   terraformApplyPlan
*   infrastructure_prefix
*   approvers
*   recoverFromADifferentVolume
*   VolumeId
*/

def bucket_key = "client-ciso/${infrastructure_prefix}splunk-stack.tfstate"

node ('deploy-client') {

  env.http_proxy=env.AWS_MANAGEMENT_PROXY
  env.https_proxy=env.AWS_MANAGEMENT_PROXY
  env.no_proxy='169.254.169.254,avivacloud.com,stash.aviva.co.uk'
  env.GIT_ASKPASS="$WORKSPACE/git_askpass.sh"
  env.TF_VAR_infrastructure_prefix="${infrastructure_prefix}"

  stage ('Checkout'){
    deleteDir()

    checkout([$class: 'GitSCM', branches: [[name: gitBranch]], userRemoteConfigs: [[credentialsId: "bitbucket", url: "https://stash.aviva.co.uk/scm/gcisoseceng/splunk-stack-v3-tfmodule.git"]]])
 
    withCredentials([usernamePassword(credentialsId: "bitbucket", usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD')]){
      
    }
  }

  stage ('Initialise'){
    dir("environments/${environment}") {
      sh "terraform version"
      //sh "terraform init -no-color -backend-config='key=${bucket_key}' -input=false "
       try {
		sh "terraform init -no-color -backend-config='key=${bucket_key}' -input=false" 
		} 
     catch(Exception e) {
		sh "terraform state replace-provider -auto-approve -- -/aws registry.terraform.io/hashicorp/aws"
		sh "terraform state replace-provider -auto-approve -- -/template registry.terraform.io/hashicorp/template"
        sh "terraform state replace-provider -auto-approve -- -/archive registry.terraform.io/hashicorp/archive"
		} 
	   sh "terraform init -no-color -backend-config='key=${bucket_key}' -input=false" 
    }
  }
  
  if (recoverFromADifferentVolume == 'true') {
		stage ('Import'){
		  dir("environments/${environment}") {
			sh "terraform import module.splunk.module.${stack}.aws_ebs_volume.volume ${VolumeId}"
		  }
		}
  } 
  
  stage ('Plan'){
    dir("environments/${environment}") {
      withCredentials([string(credentialsId: 'splunk-rebuild-hec-token', variable: 'HEC_TOKEN')]) {
        withCredentials([usernamePassword(credentialsId: 'win-domain-join', passwordVariable: 'TF_VAR_domain_join_password', usernameVariable: 'TF_VAR_domain_join_user')]) {
        sh "terraform get --update"
        if (action == 'create') {
          if (stack == 'all') {
            sh "terraform plan -var 'hec_token=${HEC_TOKEN}' -out=tfplan"
          } else {
            sh "terraform plan -var 'hec_token=${HEC_TOKEN}' -out=tfplan -target=module.splunk.module.${stack}"
          }
        } else if (action == 'destroy') {
          if (stack == 'all') {
            sh "terraform plan -var 'hec_token=${HEC_TOKEN}' -destroy -out=tfplan"
          } else {
            sh "terraform plan -var 'hec_token=${HEC_TOKEN}' -destroy -out=tfplan -target=module.splunk.module.${stack}"
          }
        }

        stash include: 'tfplan', name: 'tfplan'
        }
      }
    }
  }
}

if (terraformApplyPlan == 'true') {
  stage ('Apply Approve') {
    timeout(time:5, unit:'DAYS') {
        input id: 'ApproveDeployment', message:'Approve deployment?', ok: 'Approve', submitter: approvers
    }
  }

  node ('deploy-client') {
    stage ('Apply'){
      dir("environments/${environment}") {
        unstash 'tfplan'
        sh "terraform apply  -input=false -no-color tfplan"
        sh 'rm tfplan'
      }
    }
  }
}
