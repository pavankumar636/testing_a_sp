/*
* Copy and encrypt rhel AMI
*
* Jenkins Global Environment Variables:
*   AWS_MANAGEMENT_PROXY
*   AWS_DEFAULT_REGION
*
* Jenkins Job Parameters:
*   gitCreds
*   gitUrl
*   gitBranch
*   packerDir
*   packerTemplateFile
*   packerVarFile
*   packerLogLevel
*   accountsEncrypt
*   sourceAmi
*   targetAmiNameTag
*   ownerTag
*   costCentreTag
*   HsnTag
*/

node ('build-app') {

  env.http_proxy=env.AWS_MANAGEMENT_PROXY
  env.https_proxy=env.AWS_MANAGEMENT_PROXY
  env.no_proxy='169.254.169.254,aws-euw1-services.com'

  stage ('Checkout'){
    deleteDir()
    checkout([$class: 'GitSCM', branches: [[name: gitBranch]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'SubmoduleOption', disableSubmodules: false, parentCredentials: true, recursiveSubmodules: true, reference: '', trackingSubmodules: false]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: gitCreds, url: gitUrl]]])
  }

  // Build and encrypt AMI in each account
  if (accountsEncrypt!=''){
    accountsArray = convertStringToList(accountsEncrypt)
    for (int i = 0; i < accountsArray.size(); i++) {
      account = accountsArray.get(i)
      stage ("Encrypt AMI in ${account}") {
        try {
          createEncryptedAmi(account, sourceAmi, ownerTag, costCentreTag, HsnTag, targetAmiNameTag, packerDir, packerVarFile, packerTemplateFile, packerLogLevel)
        } catch (Exception ex) {
          currentBuild.result = "FAILURE"
          destroyPackerInstance()
          error("Encrypting AMI failed")
        }
      }
    }
  }

}

/*
* Create an encrypted AMI in a target account from a unencrypted source AMI
*/
def createEncryptedAmi(targetAccount, sourceAmi, ownerTag, costCentreTag, HsnTag, targetAmiNameTag, packerDir, packerVarFile, packerTemplateFile, packerLogLevel) {
  def amiToEncrypt
  def encryptedAmi
  def roleArn = "arn:aws:iam::${targetAccount}:role/baker"

  echo "Building encrypted AMI in ${targetAccount} from ${sourceAmi}"

  sourceAmiName = getAmiName(sourceAmi)
  env.sourceAmiName = sourceAmiName
  sh "~/bin/rake environment:app_variables_file['${roleArn}','${packerDir}/${targetAccount}_${packerVarFile}']"
  sh "~/bin/rake environment:packer_copy_win_2016_template['${roleArn}','copy-${sourceAmiName}','${sourceAmi}','${ownerTag}','${costCentreTag}','${HsnTag}','${packerDir}/${targetAccount}_${packerVarFile}','${packerDir}/${targetAccount}_${packerTemplateFile}']"

  dir(packerDir) {
    env.PACKER_LOG = packerLogLevel
    sh "packer validate ${targetAccount}_${packerTemplateFile}"
    sh "set -o pipefail; packer build -machine-readable ${targetAccount}_${packerTemplateFile} | tee ${targetAccount}-packer-build.txt"
    amiToEncrypt = sh (script: "egrep --only-matching --regexp='ami-.{17}' ${targetAccount}-packer-build.txt | tail -1", returnStdout: true).trim()
  }

  // Encrypt copied AMI
  encryptedAmi = encryptAmi(amiToEncrypt, targetAccount)

  previewTag = sh(script: "aws ec2 describe-images --image-id ${sourceAmi} --query 'Images[0].Tags[?Key==`PreviewAmi`].Value' --output text", returnStdout: true).trim() ?: "true"
  featureTag = sh(script: "aws ec2 describe-images --image-id ${sourceAmi} --query 'Images[0].Tags[?Key==`Feature`].Value' --output text", returnStdout: true).trim() ?: "base"

  // Delete copied AMI
  sh "~/bin/rake image:delete['${roleArn}','${amiToEncrypt}']"

  // Tag encrypted AMI
  sh "~/bin/rake image:tag['${roleArn}','${encryptedAmi}','Jenkins=${JOB_NAME}-${BUILD_NUMBER}','Lifecycle=available','Name=${targetAmiNameTag}-encrypted','SourceAmi=${sourceAmi}','Feature=${featureTag}','PreviewAmi=${previewTag}']"
}

/*
* Encrypt an AMI in a given account
*/
def encryptAmi(sourceAmi, awsAccount){
  def roleArn = "arn:aws:iam::${awsAccount}:role/baker"
  sh "set -o pipefail; ~/bin/rake image:encrypt['${roleArn}','${sourceAmi}'] | tee ${awsAccount}-image-encrypt.txt"
  encryptedAmi = sh (script: "egrep --only-matching --regexp='ami-.{17}' ${awsAccount}-image-encrypt.txt | tail -1", returnStdout: true).trim()
  echo "Created encrypted AMI ${encryptedAmi} from ${sourceAmi} in ${awsAccount}"
  return encryptedAmi
}

/*
 * Terminate instance
 */
def destroyPackerInstance() {
  instanceId = sh (script: "egrep --only-matching --regexp='i-(\\w){17}' ${packerDir}/packer-build.txt | head -1",
                   returnStdout: true).trim()
  echo "Destroying instance ${instanceId}"
  sh "aws ec2 terminate-instances --instance-ids ${instanceId}"
}

/*
* Returns the AMI name
*/
def getAmiName(sourceAmi) {
  amiName = sh (script: "aws ec2 describe-images --image-ids ${sourceAmi} --query 'Images[0].Name' --output text", returnStdout: true).trim()
  echo "AMI name ${amiName}"
  return amiName
}

/*
* Tags an AMI
*/
def tagAmi(awsAccount, awsAmi, tag) {
  def roleArn = "arn:aws:iam::${awsAccount}:role/baker"
  echo "Tagging AMI ${awsAmi} in ${awsAccount} with ${tag}"
  sh "~/bin/rake image:tag['${roleArn}','${awsAmi}','${tag}']"
}

/*
* Returns the value of a tag of an AMI
*/
def getAmiTagValue(awsAmi, tagName) {
    tagValue = sh(script: "aws ec2 describe-images --image-ids ${awsAmi} --query \"Images[*].Tags[?Key=='${tagName}'].Value\" --output text", returnStdout: true).trim()
    echo "AMI ${awsAmi} tag ${tagName} ${tagValue}"
    return tagValue
}

@NonCPS
def convertStringToList(inputString){
  List<String> items = Arrays.asList(inputString.split("\\s*,\\s*"));
  return items
}