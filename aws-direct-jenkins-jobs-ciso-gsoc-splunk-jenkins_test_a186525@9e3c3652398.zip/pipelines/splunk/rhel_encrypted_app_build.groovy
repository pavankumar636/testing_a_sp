/*
* Builds encrypted AMIs in multiple AWS accountts
*
* Jenkins Global Environment Variables:
*   AWS_MANAGEMENT_PROXY
*   AWS_DEFAULT_REGION
*
* Jenkins Job Parameters:
*   gitCreds
*   gitUrl
*   gitBranch
*   packerDir
*   packerTemplateFile
*   packerVarFile
*   packerUserDataFile
*   managementAccount
*   accountsShare
*   accountsEncrypt
*   terraformDir
*   terraformLogLevel
*   terraformEnvironment
*   serverspecRole
*   cisArchive
*   cisBenchmark
*   cisProfile
*   deleteUnencryptedAmi
*   ownerTag
*   costCentreTag
*   HsnTag
*/

def sourceAmi
def sourceAmiName
def hostname
def accountsArray

node ('build-app') {

  env.http_proxy=env.AWS_MANAGEMENT_PROXY
  env.https_proxy=env.AWS_MANAGEMENT_PROXY
  env.no_proxy='169.254.169.254,aws-euw1-services.com,avivagroup.com'

  stage ('Checkout'){
    deleteDir()
    checkout([$class: 'GitSCM', branches: [[name: gitBranch]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'SubmoduleOption', disableSubmodules: false, parentCredentials: true, recursiveSubmodules: true, reference: '', trackingSubmodules: false]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: gitCreds, url: gitUrl]]])
  }

  stage ('Build AMI'){
    try {
      sourceAmi = buildAmi(managementAccount, packerDir, packerVarFile, packerTemplateFile, packerLogLevel)
    } catch(Exception ex) {
      currentBuild.result = "FAILURE"
      destroyPackerInstance()
      print(ex.getMessage())
      error("Building AMI failed")
    }
    sourceAmiName = getAmiName(sourceAmi)
  }

  stage ('Test AMI'){
    try {
      hostname = startTestInstance(managementAccount, sourceAmi, terraformDir, terraformEnvironment, terraformLogLevel)
      runServerspec(hostname, serverspecRole)
      runCisCat(hostname, cisArchive, cisBenchmark, cisProfile)
    } catch(Exception ex) {
      destroyTestInstance(managementAccount, sourceAmi, terraformEnvironment, terraformLogLevel)
      currentBuild.result = "UNSTABLE"
      error("Testing for AMI failed")
    } finally {
      destroyTestInstance(managementAccount, sourceAmi, terraformEnvironment, terraformLogLevel)
    }
    tagAmi(managementAccount, sourceAmi,'Lifecycle=available')
  }

  if (accountsShare != ''){
    stage ('Share AMI'){
      shareAmi(sourceAmi, managementAccount, accountsShare)
    }
  }

  // Build and encrypt AMI in each account
  if (accountsEncrypt != ''){
    accountsArray = convertStringToList(accountsEncrypt)
    for (int i = 0; i < accountsArray.size(); i++) {
      account = accountsArray.get(i)
      stage ("Encrypt AMI in ${account}") {
        try {
          createEncryptedAmi(managementAccount, account, sourceAmi, ownerTag, costCentreTag, HsnTag, sourceAmiName, packerDir, packerVarFile, packerTemplateFile, packerLogLevel)
        } catch(Exception ex) {
          currentBuild.result = "FAILURE"
          destroyPackerInstance()
          error("Encrypting the AMI failed")
        }
      }
    }
  }

  // Delete unencrypted source AMI if its not an intermediate AMI
  if (deleteUnencryptedAmi == 'yes'){
    stage ('Delete Unencrypted AMI'){
      deleteAmi(managementAccount, sourceAmi)
    }
  }

}

/*
* Build AMI
*/
def buildAmi(awsAccount, packerDir, packerVarFile, packerTemplateFile, packerLogLevel) {
  def awsAmi
  def roleArn = "arn:aws:iam::${awsAccount}:role/baker"

  echo "Building AMI in ${awsAccount}"

  sh "~/bin/rake environment:app_variables_file['${roleArn}','${packerDir}/${packerVarFile}']"
  sh "~/bin/rake environment:rhel_user_data_file['${packerDir}/${packerVarFile}','${packerDir}/${packerUserDataFile}']"

  dir(packerDir) {
    env.PACKER_LOG = packerLogLevel
    sh "packer validate -var-file=${packerVarFile} ${packerTemplateFile}"
    sh "set -o pipefail; packer build -machine-readable -var-file=${packerVarFile} ${packerTemplateFile} | tee packer-build.txt"
    awsAmi = sh (script: "egrep --only-matching --regexp='ami-.{17}' packer-build.txt | tail -1", returnStdout: true).trim()
  }

  // Tag AMI
  awsAmiSourceAmi = getAmiTagValue(awsAmi, 'SourceAmi')
  foundationAmi = getAmiTagValue(awsAmiSourceAmi, 'FoundationAmi')
  sh "~/bin/rake image:tag['${roleArn}','${awsAmi}','Encrypted=false','FoundationAmi=${foundationAmi}','Jenkins=${JOB_NAME}-${BUILD_NUMBER}','Lifecycle=build']"

  echo "Built AMI ${awsAmi}"

  return awsAmi
}

/*
* Share an AMI with a list of accounts
*/
def shareAmi(sourceAmi, awsAccount, awsAccountList) {
  def roleArn = "arn:aws:iam::${awsAccount}:role/baker"
  echo "Sharing AMI ${sourceAmi} from ${awsAccount} with ${awsAccountList}"
  sh "~/bin/rake image:share['${roleArn}','${sourceAmi}','${awsAccountList}']"

}

/*
* Create an encrypted AMI in a target account from a unencrypted source AMI
*/
def createEncryptedAmi(managementAccount, awsAccount, sourceAmi, ownerTag, costCentreTag, HsnTag, sourceAmiName, packerDir, packerVarFile, packerTemplateFile, packerLogLevel) {
  def encryptedAmi
  def amiToEncrypt
  def roleArn = "arn:aws:iam::${awsAccount}:role/baker"

  echo "Creating encrypted AMI in ${awsAccount} from ${sourceAmi} ${sourceAmiName}"

  // Create a copy of the source AMI unless you are in the account it was created in
  if (managementAccount != awsAccount) {
    env.PACKER_LOG = packerLogLevel

    sh "~/bin/rake environment:app_variables_file['${roleArn}','${packerDir}/${awsAccount}_${packerVarFile}']"
    sh "~/bin/rake environment:packer_copy_template['${roleArn}','copy-${sourceAmiName}','${sourceAmi}','${ownerTag}','${costCentreTag}','${HsnTag}','${packerDir}/${awsAccount}_${packerVarFile}','${packerDir}/${awsAccount}_${packerTemplateFile}']"

    dir(packerDir) {
      
      sh "packer validate ${awsAccount}_${packerTemplateFile}"
      sh "set -o pipefail; packer build -machine-readable ${awsAccount}_${packerTemplateFile} | tee ${awsAccount}-packer-build.txt"
      amiToEncrypt = sh (script: "egrep --only-matching --regexp='ami-.{17}' ${awsAccount}-packer-build.txt | tail -1", returnStdout: true).trim()
    }

  } else {
    amiToEncrypt = sourceAmi
  }

  // Encrypt AMI
  encryptedAmi = encryptAmi(amiToEncrypt, awsAccount)

  // Delete copied AMI if one was created
  if (managementAccount != awsAccount) {
    deleteAmi(awsAccount, amiToEncrypt)
  }

  // Tag AMI
  sourceAmiNameTag = getAmiTagValue(sourceAmi, 'Name')
  sourceAmiSourceTag = getAmiTagValue(sourceAmi, 'SourceAmi')
  sh "~/bin/rake image:tag['${roleArn}','${encryptedAmi}','Jenkins=${JOB_NAME}-${BUILD_NUMBER}','Lifecycle=available','Name=${sourceAmiNameTag}-encrypted','SourceAmi=${sourceAmiSourceTag}']"
}

/*
* Encrypt AMI in a given account
*/
def encryptAmi(sourceAmi, awsAccount){
  def roleArn = "arn:aws:iam::${awsAccount}:role/baker"
  echo "Encrypting AMI ${sourceAmi} in ${awsAccount}"
  sh "set -o pipefail; ~/bin/rake image:encrypt['${roleArn}','${sourceAmi}'] | tee ${awsAccount}-image-encrypt.txt"
  encryptedAmi = sh (script: "egrep --only-matching --regexp='ami-.{17}' ${awsAccount}-image-encrypt.txt | tail -1", returnStdout: true).trim()
  echo "Created encrypted AMI ${encryptedAmi}"
  return encryptedAmi
}

/*
* Start Terraform test instance
*/
def startTestInstance(awsAccount, awsAmi, terraformDir, environment, terraformLogLevel) {
  def hostname

  echo "Starting test instance using ${awsAmi} in ${environment} ${awsAccount}"

  env.TF_VAR_image_id = awsAmi
  env.TF_VAR_aws_provider_role = "arn:aws:iam::${awsAccount}:role/tester-baker"
  env.TF_VAR_environment = environment
  env.TF_LOG = terraformLogLevel

  dir(terraformDir) {
    // Version check can be removed once v0.8.4 is decommissioned
    terraformVersion = sh (script: "terraform --version", returnStdout: true).trim()
    echo "tf ver: ${terraformVersion}"
    if (terraformVersion != 'Terraform v0.8.4') {
      sh "terraform init -input=false"
    }
    sh "terraform plan -input=false -out=tfplan"
    sh "terraform apply -input=false tfplan"
    hostname = sh (script: "terraform output hostname", returnStdout: true).trim()
  }

  // Wait for SSH to be available
  withCredentials([file(credentialsId: 'jenkins-testing', variable: 'SSH_KEY_FILE')]) {
    retry(10) {
      sleep 10
      sh "ssh -o StrictHostKeyChecking=no -o BatchMode=yes -i ${SSH_KEY_FILE} ec2-user@${hostname}"
    }
  }

  return hostname
}

/*
 * Terminate instance
 */
def destroyPackerInstance() {
  instanceId = sh (script: "egrep --only-matching --regexp='i-(\\w){17}' ${packerDir}/packer-build.txt | head -1",
                   returnStdout: true).trim()
  echo "Destroying instance ${instanceId}"
  sh "aws ec2 terminate-instances --instance-ids ${instanceId}"
}

/*
* Terminate Terraform test instance
*/
def destroyTestInstance(awsAccount, awsAmi, environment, terraformLogLevel){
  echo "Destroying test instance ${awsAmi} in ${environment} ${awsAccount}"

  env.TF_VAR_image_id = awsAmi
  env.TF_VAR_aws_provider_role = "arn:aws:iam::${awsAccount}:role/tester-baker"
  env.TF_VAR_environment = environment
  env.TF_LOG = terraformLogLevel

  dir(terraformDir) {
    terraformVersion = sh (script: "terraform --version", returnStdout: true).trim()
    echo "tf ver: ${terraformVersion}"
    // if block and Version check can be removed once versions less than 0.11 is decommissioned
    if (terraformVersion == 'Terraform v0.11.10') {
      sh "terraform destroy -input=false -auto-approve"
    } else {
        sh "terraform destroy -force"
    }
  }
}

/*
* Run ServerSpec Tests
*/
def runServerspec(hostname, serverspecRole){
  echo "Running ServerSpec ${serverspecRole} on ${hostname}"

  env.TARGET_HOST = hostname

  sleep time: 1, unit: 'MINUTES'
  withCredentials([file(credentialsId: 'jenkins-testing', variable: 'SSH_KEY_FILE')]) {
    sh "~/bin/rake ${serverspecRole}"
  }
  archive 'serverspec.*'
}

/*
* Run cis-cat Tests
*/
def runCisCat(hostname, cisArchive, cisBenchmark, cisProfile) {
  echo "Running cis-cat on ${hostname}"

  cisCatOptions = '--accept-terms --status'

  withCredentials([file(credentialsId: 'jenkins-testing', variable: 'SSH_KEY_FILE')]) {
    sh "ssh -tt -o StrictHostKeyChecking=no -o BatchMode=yes -i ${SSH_KEY_FILE} ec2-user@${hostname} 'sudo yum install -y java' "

    sh "curl https://binaries.avivagroup.com/artifactory/aws-direct-platform-sysops-generic-local/ciscat/v3/${cisArchive} --output ${cisArchive}"
    sh "scp -o StrictHostKeyChecking=no -o BatchMode=yes -i ${SSH_KEY_FILE}  ./${cisArchive} ec2-user@${hostname}:/home/ec2-user/${cisArchive}"
    sh "ssh -o StrictHostKeyChecking=no -o BatchMode=yes -i ${SSH_KEY_FILE} ec2-user@${hostname} 'unzip -qq -o /home/ec2-user/${cisArchive} -d /home/ec2-user' "
    sh "ssh -tt -o StrictHostKeyChecking=no -o BatchMode=yes -i ${SSH_KEY_FILE} ec2-user@${hostname} 'sudo chmod +x /home/ec2-user/cis-cat-full/CIS-CAT.sh' "
    sh "ssh -tt -o StrictHostKeyChecking=no -o BatchMode=yes -i ${SSH_KEY_FILE} ec2-user@${hostname} 'cd /home/ec2-user/cis-cat-full; sudo ./CIS-CAT.sh ${cisCatOptions} --benchmark ${cisBenchmark} --profile ${cisProfile} --results-dir /home/ec2-user --report-name cis-cat-report --report-txt; sudo chmod 777 ~/cis-cat-report.*' "
    sh "scp -o StrictHostKeyChecking=no -o BatchMode=yes -i ${SSH_KEY_FILE} ec2-user@${hostname}:/home/ec2-user/cis-cat-report.* ."
  }
  archive 'cis-cat-report.*'
}

/*
* Deletes an AMI name from a given account
*/
def deleteAmi(awsAccount, awsAmi) {
  def roleArn = "arn:aws:iam::${awsAccount}:role/baker"
  echo "Deleting AMI ${awsAmi} in ${awsAccount}"
  sh "~/bin/rake image:delete['${roleArn}','${awsAmi}']"
}

/*
* Retrieves AMI name from current account
*/
def getAmiName(sourceAmi) {
  amiName = sh (script: "aws ec2 describe-images --image-ids ${sourceAmi} --query 'Images[*].{Name:Name}' --output text", returnStdout: true).trim()
  echo "AMI name ${amiName}"
  return amiName
}

/*
* Tags an AMI
*/
def tagAmi(awsAccount, awsAmi, tag) {
  def roleArn = "arn:aws:iam::${awsAccount}:role/baker"
  echo "Tagging AMI ${awsAmi} in ${awsAccount} with ${tag}"
  sh "~/bin/rake image:tag['${roleArn}','${awsAmi}','${tag}']"
}

/*
* Returns the value of a tag of an AMI
*/
def getAmiTagValue(awsAmi, tagName) {
    tagValue = sh(script: "aws ec2 describe-images --image-ids ${awsAmi} --query \"Images[*].Tags[?Key=='${tagName}'].Value\" --output text", returnStdout: true).trim()
    echo "AMI Tag Value for ${awsAmi} tag ${tagName} ${tagValue}"
    return tagValue
}

@NonCPS
def convertStringToList(inputString){
  List<String> items = Arrays.asList(inputString.split("\\s*,\\s*"));
  return items
}