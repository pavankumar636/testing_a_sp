/*
* Pipeline For Instance Start and Stop
*
* Jenkins Environment Variables:
*   AWS_MANAGEMENT_PROXY
*   AWS_DEFAULT_REGION
*
* Jenkins Job Parameters:
*   environment
*   gitBranch
*   ApplyPlan
*   infrastructure_prefix
*/
def awsDefaultRegion   = 'eu-west-1'
node ('deploy-client-tfv11') {
             
  env.http_proxy=env.AWS_MANAGEMENT_PROXY
  env.https_proxy=env.AWS_MANAGEMENT_PROXY
  env.no_proxy='169.254.169.254,aws-euw1-services.com,127.0.0.1,localhost'
 
  
//Start the Instance
    stage ('Start/Stop Instance') {
      echo "${ApplyPlan}"
      echo "${action}"

            if(action == 'start'){
                startInstance(awsAccount)
            }
            
            if(action == 'stop'){
                stopInstance(awsAccount)
            }
        

		
		
    }
}
//------------- Instance Instance -----------------
def startInstance(AccountID){
    env.awsAccount = "${AccountID}"
  	sh '''
    STS_CRED=( $(aws sts assume-role --role-arn arn:aws:iam::${awsAccount}:role/ciso-gsoc-splunk/ciso-gsoc-splunk-deployer --role-session-name role_session --query 'Credentials.[SecretAccessKey, SessionToken, AccessKeyId]' --output text))
    set +x
	export AWS_SECRET_ACCESS_KEY=${STS_CRED[0]}
	export AWS_SESSION_TOKEN=${STS_CRED[1]}
	export AWS_ACCESS_KEY_ID=${STS_CRED[2]}
    set -x
	// INSTANCE_ID=( $(aws ec2 describe-instances --filters "Name=tag:Name,Values=np-*.splunk" --query 'Reservations[*].Instances[*].[InstanceId]' --output text ))
    INSTANCE_ID=( $(aws ec2 describe-instances --filters "Name=tag:Name,Values=np-utility-server-1.splunk,np-sh-*,np-indexer-*,np-heavy-forwarder-*,np-deployment-server-1.splunk" --query 'Reservations[*].Instances[*].[InstanceId]' --output text ))
	
   
	if [ ${ApplyPlan} == "No" ]; then
		if [ ${INSTANCE_ID[0]} != "" ]; then
			echo "Following instances are going to start:"
			echo ${INSTANCE_ID[*]}
		else  
			echo "Cannot find suitable instance to start"
		fi
			
	else
		if [ ${INSTANCE_ID[0]} != "" ]; then
			echo "Following instances are going to start:"
			echo ${INSTANCE_ID[*]}
			InstanceCount=${#INSTANCE_ID[@]}
			echo ${InstanceCount}
				for i in $(seq 0 $(( $InstanceCount - 1 )));  
				do 		    
				   aws ec2 start-instances --instance-ids ${INSTANCE_ID[i]}
			       echo "Starting Instance ${INSTANCE_ID[i]}"
				done
		else  
			echo "Cannot find suitable instance to start"
		fi

	fi
		
    
	'''
}
def stopInstance(AccountID){
    env.awsAccount = "${AccountID}"
   sh '''
    STS_CRED=( $(aws sts assume-role --role-arn arn:aws:iam::${awsAccount}:role/ciso-gsoc-splunk/ciso-gsoc-splunk-deployer --role-session-name role_session --query 'Credentials.[SecretAccessKey, SessionToken, AccessKeyId]' --output text))
	set +x
	export AWS_SECRET_ACCESS_KEY=${STS_CRED[0]}
	export AWS_SESSION_TOKEN=${STS_CRED[1]}
	export AWS_ACCESS_KEY_ID=${STS_CRED[2]}
    set -x
	INSTANCE_ID=( $(aws ec2 describe-instances --filters "Name=instance-state-name,Values=running" "Name=tag:Name,Values=*.splunk" --query 'Reservations[*].Instances[*].[InstanceId]' --output text ))
	if [ ${ApplyPlan} == "No" ]; then
		if [ ${INSTANCE_ID[0]} != "" ]; then
			echo "Following instances are going to stop:"
			echo ${INSTANCE_ID[*]}
		else  
			echo "Cannot find suitable instance to stop"
		fi
			
	else
		if [ ${INSTANCE_ID[0]} != "" ]; then
			echo "Following instances are going to stop:"
			echo ${INSTANCE_ID[*]}
			InstanceCount=${#INSTANCE_ID[@]}
			echo ${InstanceCount}
				for i in $(seq 0 $(( $InstanceCount - 1 )));  
				do 
				aws ec2 stop-instances --instance-ids ${INSTANCE_ID[i]}
				echo "Stopping Instance ${INSTANCE_ID[i]}"
				done
		else  
			echo "Cannot find suitable instance to stop"
		fi
	fi	
    
	'''
} 
    	

