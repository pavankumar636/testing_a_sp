/*
* Build encrypted AMI
*
* Jenkins Global Environment Variables:
*   AWS_MANAGEMENT_PROXY
*   AWS_DEFAULT_REGION
*
* Jenkins Job Parameters:
*   gitCreds
*   gitUrl
*   gitBranch
*   packerDir
*   packerTemplateFile
*   packerVarFile
*   packerLogLevel
*   managementAccount
*   accountsShare
*   accountsEncrypt
*   terraformDir
*   terraformEnvironment
*   terraformLogLevel
*   domainName
*   ouPath
*   serverspecRole
*   cisArchive
*   cisBenchmark
*   cisProfile
*   deleteUnencryptedAmi
*   environment
*   gitPuppetRepo
*   gitPuppetBranch
*   bakery_proxy_dns_name
*   wsus_dns_name
*/

def awsDefaultRegion   = 'eu-west-1'

node ('build-app-tfv11') {

  env.http_proxy       = env.AWS_MANAGEMENT_PROXY
  env.https_proxy      = env.AWS_MANAGEMENT_PROXY
  env.no_proxy         ='169.254.169.254,avivacloud.com,compute.internal'

  // Checkout git repository on local Jenkins platform
  if (awsAccount == 'managementAccount') {
	stage ('Delete AMIs/Snapshots') {
    if(deleteBy == 'AMI_NAME'){
		    deleteAmi(tagsFilter, AmiName, managementAccountID, latestAmiCount)
    }
    if(deleteBy == 'AMI_ID'){
       deleteAmiById(amiID, managementAccountID)
    }
    if(deleteBy == 'SNAP_ID'){
      deleteSnapshotById(snapID, managementAccountID)
    }
	}
  }

  if (awsAccount == 'cisoAccount') {
	stage ('Delete AMIs/Snapshots') {
    if(deleteBy == 'AMI_NAME'){
        deleteAmi(tagsFilter, AmiName, clientAccountID, latestAmiCount)
    }
    if(deleteBy == 'AMI_ID'){
        deleteAmiById(amiID, clientAccountID)
    }
    if(deleteBy == 'SNAP_ID'){
      deleteSnapshotById(snapID, clientAccountID)
    }
	}
  }
}

//------------AMI delete------
def deleteAmi(tagsFilter, AmiName, AccountID, latestAmiCount){
	env.AccountIDNumber = "${AccountID}"
	env.Ami_Name = "${AmiName}"
	env.tags_Filter = "${tagsFilter}"

  if(latestAmiCount.toInteger() < 4)
  {
    env.latest_Ami = 4
    echo "latestAmiCount is less than permitted number, hence defaulting to 4"
  }
  else{
    env.latest_Ami_Count = "${latestAmiCount}".toInteger()
    echo "Setting latestAmiCount set to ${latestAmiCount}"
  }
	sh '''
	AmiCount=0
	STS_CRED=( $(aws sts assume-role --role-arn arn:aws:iam::${AccountIDNumber}:role/baker --role-session-name role_session --query 'Credentials.[SecretAccessKey, SessionToken, AccessKeyId]' --output text) )
	export AWS_SECRET_ACCESS_KEY=${STS_CRED[0]}
	export AWS_SESSION_TOKEN=${STS_CRED[1]}
	export AWS_ACCESS_KEY_ID=${STS_CRED[2]}
	'''
  def amiIds = sh (script: "aws ec2 describe-images --filters 'Name=tag:HSN,Values=$tags_Filter','Name=tag:Name,Values=*$Ami_Name*' --query 'sort_by(Images, &CreationDate)[0:-${latest_Ami_Count}].[ImageId][]|join(`,`, @)' --output text", returnStdout: true).trim()

  if(amiIds != "") {
			def amis = convertStringToList(amiIds)
      echo "AMIs to delete are ${amis}"
      amiCount=0
      snapCount=0
      for (int i = 0; i < amis.size(); i++) {
        ami = amis.get(i)
        sh (script:"aws ec2 deregister-image --image-id $ami || true", returnStdout: true)
        amiCount=amiCount+1
        snapCount = deleteSnapshot(ami,snapCount)
      }

      echo "Total AMIs deleted : ${amiCount} and Snapshots deleted : ${snapCount}"
    }
  else{
    echo "AMI LIST EMPTY!"
  }

}
//------------Snapshot delete------
def deleteSnapshot(ami,snapCount){

	def snapId = sh (script: "aws ec2 describe-snapshots --filters 'Name=description,Values=*$ami*' --query 'Snapshots[*].{id: SnapshotId}' --output text", returnStdout: true)

  if(snapId != ""){
  	echo "Deleting corresponding snapshotID $snapId"
  	sh(script: "aws ec2 delete-snapshot --snapshot-id $snapId")
    snapCount=snapCount+1
  }
  else{
      echo "Snapshot ID Null or EMPTY!"
  }
  return snapCount
}

def deleteAmiById(amiID,AccountID){
  env.AccountIDNumber = "${AccountID}"
  env.Ami_Name = "${amiID}"

  sh '''
  AmiCount=0
  STS_CRED=( $(aws sts assume-role --role-arn arn:aws:iam::${AccountIDNumber}:role/baker --role-session-name role_session --query 'Credentials.[SecretAccessKey, SessionToken, AccessKeyId]' --output text) )
  export AWS_SECRET_ACCESS_KEY=${STS_CRED[0]}
  export AWS_SESSION_TOKEN=${STS_CRED[1]}
  export AWS_ACCESS_KEY_ID=${STS_CRED[2]}
  aws ec2 deregister-image --image-id $Ami_Name || true
  exit 0
  '''
}

def deleteSnapshotById(snapID,AccountID){
  env.AccountIDNumber = "${AccountID}"
  env.snap_ID = "${snapID}"

  sh '''
  AmiCount=0
  STS_CRED=( $(aws sts assume-role --role-arn arn:aws:iam::${AccountIDNumber}:role/baker --role-session-name role_session --query 'Credentials.[SecretAccessKey, SessionToken, AccessKeyId]' --output text) )
  export AWS_SECRET_ACCESS_KEY=${STS_CRED[0]}
  export AWS_SESSION_TOKEN=${STS_CRED[1]}
  export AWS_ACCESS_KEY_ID=${STS_CRED[2]}
  aws ec2 delete-snapshot --snapshot-id $snap_ID
  exit 0
  '''
}

def convertStringToList(inputString){
  List<String> items = Arrays.asList(inputString.split("\\s*,\\s*"));
  return items
}
