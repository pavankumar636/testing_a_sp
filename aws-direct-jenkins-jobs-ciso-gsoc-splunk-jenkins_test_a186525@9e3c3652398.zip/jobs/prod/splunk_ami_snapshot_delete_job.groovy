pipelineJob('ciso-gsoc-splunk-ami-snapshot-cleanup') {
  description('')
  logRotator(5, 5)
  parameters {
    choiceParam('awsAccount',['managementAccount',  'cisoAccount'],'')
    choiceParam('managementAccountID', ['281077040066'], '')
    choiceParam('clientAccountID', ['565933204446'], 'Choose any')
    choiceParam('deleteBy', ['AMI_ID', 'AMI_NAME', 'SNAP_ID'], 'Choose if you want to delete by specific AMI ID or by AMI Name or by SnapshotId')
    stringParam('amiID', '', 'Enter the AMI ID which needs to be deregistered from the chosen account')
    stringParam('snapID', '', 'Enter the SNAPSHOT ID which needs to be deleted from the chosen account')
    stringParam('AmiName', '', 'Enter the APP name until the environment e.g. splunk-test, populate if deletion to be done by AMI_NAME else leave empty')
    stringParam('latestAmiCount', '', 'Enter the number of latest AMIs which needs to be retained from the chosen account minimum=4, populate if deletion to be done by AMI_NAME else leave empty')
    stringParam('tagsFilter', '', 'Select the relevant environments HSN ex: SECURITY EVENT LOGGING NPE AWD, populate if deletion to be done by AMI_NAME else leave empty')

  }
  definition {
    cps {
      script(readFileFromWorkspace('pipelines/splunk/ami_delete.groovy'))
	  sandbox()
    }
  }
}
