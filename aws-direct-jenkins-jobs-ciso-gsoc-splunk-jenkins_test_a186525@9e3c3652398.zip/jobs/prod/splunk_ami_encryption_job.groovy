// Git repository holding packer scripts
def gitCreds           			= 'bitbucket'
def gitBuildRepo       			= 'https://stash.aviva.co.uk/scm/gcisoseceng/splunk-ami-v1-build.git'
def gitBranch      	   			= 'master'

// Environment specific parameters
def environment                 = 'prod'
def clientAccount               = '281077040066'
def ownerTag                    = 'splunkalerts@aviva.com'
def costCentreTag               = '9V845'
def HsnTag                      = 'SECURITY EVENT LOGGING PRD AWD'
def packerDir                   = 'packer'

pipelineJob('ciso-gsoc-splunk-ami-encrypt') {
  description('Splunk AMI Encryption Job')
  logRotator(5, 5)
  parameters {
    choiceParam('gitCreds', [gitCreds], '')
    choiceParam('gitUrl', [gitBuildRepo], '')
    stringParam('gitBranch', gitBranch, 'git packer branch name')
    choiceParam('packerDir', [packerDir], '')
    choiceParam('packerTemplateFile', ['splunk.json','puppet-master.json'], 'Select Packer Template to Build')
    choiceParam('packerVarFile', ['variables.json'], '')
    choiceParam('packerLogLevel', ['0', '1'], '')
    stringParam('sourceAmi', '', 'Enter the source AMI')
    //choiceParam('targetAmiNameTag', ['gsoc-splunk-prod-ami','gsoc-splunk-puppetmaster-ami'], '')
    choiceParam('accountsEncrypt', ['565933204446'], '')
	choiceParam('ownerTag', [ownerTag], '')
	choiceParam('costCentreTag', [costCentreTag], '')
	choiceParam('HsnTag', [HsnTag], '')
  }
  definition {
    cps {
      script(readFileFromWorkspace('pipelines/splunk/rhel_copy_encrypt.groovy'))
      sandbox()
    }
  }
}

pipelineJob('ciso-gsoc-splunk-win-ami-encrypt') {
  description('Splunk AMI Encryption Job')
  logRotator(5, 5)
  parameters {
    choiceParam('gitCreds', [gitCreds], '')
    choiceParam('gitUrl', [gitBuildRepo], '')
    stringParam('gitBranch', gitBranch, 'git packer branch name')
    choiceParam('packerDir', [packerDir], '')
    choiceParam('packerTemplateFile', ['splunk.json'], 'Select Packer Template to Build')
    choiceParam('packerVarFile', ['variables.json'], '')
    choiceParam('packerLogLevel', ['0', '1'], '')
    stringParam('sourceAmi', '', 'Enter the source AMI')
    choiceParam('targetAmiNameTag', ['gsoc-splunk-prod-win-ami'], '')
    choiceParam('accountsEncrypt', ['565933204446'], '')
	choiceParam('ownerTag', [ownerTag], '')
	choiceParam('costCentreTag', [costCentreTag], '')
	choiceParam('HsnTag', [HsnTag], '')
  }
  definition {
    cps {
      script(readFileFromWorkspace('pipelines/splunk/win_copy_encrypt.groovy'))
      sandbox()
    }
  }
}
