pipelineJob('ciso-gsoc-splunk-staging-deploy') {
  description('Deploy Splunk Staging Server')
  logRotator(5, 5)
  parameters {
    choiceParam('environment', ["prod"], '')
    choiceParam('action', ['create', 'destroy'], '')
    stringParam('gitBranch', 'master', 'Enter the Git branch to use')
    stringParam('infrastructure_prefix', '', 'Infrastructure Prefix (Optional)')
    booleanParam('terraformApplyPlan', false, 'Run Terraform Apply')
  }
  definition {
    cps {
      script(readFileFromWorkspace('pipelines/splunk-staging/infrastructure.groovy'))
      sandbox()
    }
  }
}