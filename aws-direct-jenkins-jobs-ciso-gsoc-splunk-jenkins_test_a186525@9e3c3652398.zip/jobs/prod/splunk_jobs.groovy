pipelineJob('ciso-gsoc-splunk-deploy') {
  description('Deploy Splunk Stack')
  logRotator(5, 5)
  parameters {
    choiceParam('environment', ["prod"], '')
    choiceParam('action', ['create', 'destroy'], '')
    choiceParam('stack', ['all', 'deployment_server', 'universal_forwarder1', 'universal_forwarder2', 'universal_forwarder_components', 'heavy_forwarders_components', 'heavy_forwarder1', 'heavy_forwarder2', 'heavy_forwarder3', 'heavy_forwarder4', 'search_head_components', 'search_head1', 'search_head2', 'search_head3', 'indexer_components', 'indexer1', 'indexer2', 'indexer3', 'indexer4', 'indexer5', 'indexer6', 'indexer7', 'indexer8', 'indexer9', 'utility_server', 'sns'], '')
    stringParam('gitBranch', 'master', 'Enter the Git branch to use')
	booleanParam('recoverFromADifferentVolume', false, 'Launch instance with a backup volume')
	stringParam('VolumeId', '', 'Enter the new VolumeId to restore the instance with')
    stringParam('infrastructure_prefix', '', 'Infrastructure Prefix (Optional)')
    booleanParam('terraformApplyPlan', false, 'Run Terraform Apply')
    choiceParam('approvers', ['rol_splunk_deployer_uknp'], '')
  }
  definition {
    cps {
      script(readFileFromWorkspace('pipelines/splunk/infrastructure.groovy'))
      sandbox()
    }
  }
}
