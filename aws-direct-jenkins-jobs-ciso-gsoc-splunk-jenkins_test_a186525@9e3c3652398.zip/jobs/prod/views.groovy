nestedView('CISO') {
  description('')
  views {
    nestedView('admin') {
      description('')
      views {
        listView('seedjobs') {
          description('')
          jobs {
            name ('admin-seedjob-ciso-gsoc-splunk')
          }
          columns {
            status()
            weather()
            name()
            lastSuccess()
            lastFailure()
            lastDuration()
            buildButton()
          }
        }
      }
    }
    nestedView('gsoc') {
      description('')
      views {
        listView('All') {
          description('')
          jobs {
            name ('admin-seedjob-ciso-gsoc-splunk')
            regex(/ciso-.*/)
          }
          columns {
            status()
            weather()
            name()
            lastSuccess()
            lastFailure()
            lastDuration()
            buildButton()
          }
        }
        listView('splunk') {
          description('')
          jobs {
            regex(/ciso-gsoc-splunk.*/)
          }
          columns {
            status()
            weather()
            name()
            lastSuccess()
            lastFailure()
            lastDuration()
            buildButton()
          }
        }
      }
    }	
	nestedView('DLP') {
      description('')
      views {
		nestedView('admin') {
			description('')
			views {
				listView('seedjobs') {
					description('')
					jobs {
						name ('admin-seedjob-ciso-macie')
					}
					columns {
						status()
						weather()
						name()
						lastSuccess()
						lastFailure()
						lastDuration()
						buildButton()
					}
				}
			}
		}	
        listView('All') {
          description('')
          jobs {
            name ('admin-seedjob-ciso-macie')
            regex(/ciso-macie.*/)
          }
          columns {
            status()
            weather()
            name()
            lastSuccess()
            lastFailure()
            lastDuration()
            buildButton()
          }
        }
        listView('macie') {
          description('')
          jobs {
            regex(/ciso-macie.*/)
          }
          columns {
            status()
            weather()
            name()
            lastSuccess()
            lastFailure()
            lastDuration()
            buildButton()
          }
        }
      }
    }
	
  }
}
