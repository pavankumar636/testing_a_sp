//Jenkins job for the AMI build - Win Splunk application

// Git repository holding terraform/packer scripts
def gitCreds             = 'bitbucket'
def gitBuildRepo         = 'https://stash.aviva.co.uk/scm/gcisoseceng/splunk-ami-v1-build.git'
def gitBranch      		   = 'develop'


// CISCAT profile and bencmark details for Windows AMI
def cisArchive         = 'ciscat-full-bundle-2017-04-28-v3.0.36.zip'
def cisBenchmark       = 'benchmarks/CIS_Microsoft_Windows_Server_2016_Benchmark_v1.0.0-xccdf.xml'
def cisProfile         = 'xccdf_org.cisecurity.benchmarks_profile_Level_2_-_Member_Server'

// Environment specific parameters
def environment          = 'nonprod'
def managementAccount    = '906261169288'
def prodManagementAccount= '281077040066'
def cisoAccount          = '945457899050'
def prodCisoAccount      = '565933204446'
def accountsShare        = "${cisoAccount},${prodCisoAccount}"
def accountsEncrypt      = "${cisoAccount}"
def domainName           = "aviva001.com"
def ouPath               = "ou=bakery,ou=nonprod,dc=aviva001,dc=com"

// Application specific parameters
def packerDir             = 'packer'
def terraformDir_win      = 'terraform_win'
def terraformEnvironment  = "${environment}"
def wsus_dns_name         = "wsus.management.aws-euw1-np.avivacloud.com"
def bakery_proxy_dns_name = "bakery-proxy.management.aws-euw1-np.avivacloud.com"

//Build Pipeline for Windows AMI
pipelineJob('ciso-gsoc-splunk-win-server-ami-build') {
  description('Packer build of Windows universal forwarder encrypted AMI for Splunk application')
  logRotator(5, 5)
  parameters {
    choiceParam('gitCreds', [gitCreds], '')
    choiceParam('gitUrl', [gitBuildRepo], '')
    stringParam('gitBranch', 'develop', '')
    choiceParam('packerDir', [packerDir], '')
    choiceParam('packerTemplateFile', ['splunk_windows.json'], '')
    choiceParam('packerVarFile', ['variables.json'], '')
    choiceParam('packerLogLevel', ['0', '1'], '')
    choiceParam('managementAccount', [managementAccount], '')
    choiceParam('accountsShare', [accountsShare], '')
    choiceParam('accountsEncrypt', [accountsEncrypt], '')
  	choiceParam('environment', [environment], '')
    choiceParam('terraformDir', [terraformDir_win], '')
    choiceParam('terraformEnvironment', [environment], '')
    choiceParam('terraformLogLevel', ['','ERROR', 'WARN', 'INFO', 'DEBUG'], '')
    choiceParam('domainName', [domainName], '')
    choiceParam('ouPath', [ouPath], '')
    choiceParam('bakery_proxy_dns_name', [bakery_proxy_dns_name], '')
    choiceParam('wsus_dns_name', [wsus_dns_name], '')
	  choiceParam('serverspecRole', ['test:all'], '')
    choiceParam('cisArchive', [cisArchive], '')
    choiceParam('cisBenchmark', [cisBenchmark], '')
    choiceParam('cisProfile', [cisProfile], '')
    choiceParam('deleteUnencryptedAmi', ['no','yes'], '')
    stringParam('arti_user', '', 'Artifactory user name')
    nonStoredPasswordParam('arti_pass', '') 
  }
  definition {
    cps {
      script(readFileFromWorkspace('pipelines/splunk/win_encrypted_app_build.groovy'))
	  sandbox()
    }
  }
}
