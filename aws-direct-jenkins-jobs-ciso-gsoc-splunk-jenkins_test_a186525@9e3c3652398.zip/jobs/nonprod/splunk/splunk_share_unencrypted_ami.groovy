//  Share & Encrypt Pipeline
pipelineJob('ciso-gsoc-splunk-share-ami') {
  description('Share and Encrypt AMIs')
  logRotator(5, 5)
  parameters {
    stringParam('gitUrl', 'https://stash.aviva.co.uk/scm/gcisoseceng/splunk-ami-v1-build.git', 'Packer git Url')
    stringParam('gitBranch', 'develop', 'Packer git branch')
    stringParam('sourceAccount', '906261169288', 'Management account')
	stringParam('sourceAmi', '', 'Source AMI name')
	stringParam('accountsShare', '565933204446', 'Destination account number')
     }
  definition {
    cps {
      script(readFileFromWorkspace('pipelines/splunk/ami_share.groovy'))
	  sandbox()
    }
  }
}