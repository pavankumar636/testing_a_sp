def gitCreds                    = 'bitbucket'
def gitDeployRepo               = 'https://stash.aviva.co.uk/scm/gcisoseceng/puppetenterprise.git'
def gitBranch                   = 'master'

pipelineJob('ciso-gsoc-splunk-puppet-master-deploy') {
description('Deploy pipeline all stacks for Puppet Master')

  logRotator(10, 10)
  parameters {
    choiceParam('gitCreds', [gitCreds], '')
    choiceParam('gitUrl', [gitDeployRepo], '')
    stringParam('gitBranch', gitBranch, 'Git branch name')
    choiceParam('terraformenv', ["nonprod","poc"],'')
    choiceParam('terraformaccounttype', ["nonprod"], 'The account type the job will run against')

    booleanParam('tfPlanSharedStorage', false, 'terraform plan on Storage (S3)')
    booleanParam('tfPlanSharedKMS', false, 'terraform plan on Encryption (KMS)')
    booleanParam('tfPlanSharedNetwork', false, 'terraform plan on App tier Network (SGs)')
    booleanParam('tfPlanSharedSNS', false, 'terraform plan on NWM SNS')
    booleanParam('tfPlanSharedNLB', false, 'terraform plan on NWM NLB')

    booleanParam('tfPlanASG', false, 'terraform plan on Windows ASG for NWM application frontend')
    booleanParam('tfPlanDNS', false, 'terraform plan on Windows DNS for NWM application frontend')
    // ApplyPlan
    choiceParam('approvers', ['rol_splunk_deployer_uknp'], '')
    booleanParam('terraformApplyPlan', false, 'terraform APPLY on above selected terraform plans')
    }
  definition {
    cps {
      script(readFileFromWorkspace('pipelines/splunk/puppet_master_deploy.groovy'))
      sandbox()
    }
  }
}

pipelineJob('ciso-gsoc-splunk-puppet-master-destroy') {
description('Destroy pipeline all stacks for Puppet Master')

  logRotator(10, 10)
  parameters {
    choiceParam('gitCreds', [gitCreds], '')
    choiceParam('gitUrl', [gitDeployRepo], '')
    stringParam('gitBranch', gitBranch, 'Git branch name')
    choiceParam('terraformenv', ["nonprod","poc"],'')
    choiceParam('terraformaccounttype', ["nonprod"], 'The account type the job will run against')

    booleanParam('tfPlanSharedStorage', false, 'terraform plan on Storage (S3)')
    booleanParam('tfPlanSharedKMS', false, 'terraform plan on Encryption (KMS)')
    booleanParam('tfPlanSharedNetwork', false, 'terraform plan on App tier Network (SGs)')
    booleanParam('tfPlanSharedSNS', false, 'terraform plan on NWM SNS')
    booleanParam('tfPlanSharedNLB', false, 'terraform plan on NWM NLB')

    booleanParam('tfPlanASG', false, 'terraform plan on Windows ASG for NWM application frontend')
    booleanParam('tfPlanDNS', false, 'terraform plan on Windows DNS for NWM application frontend')
    // ApplyPlan
    choiceParam('approvers', ['rol_splunk_deployer_uknp'], '')
    booleanParam('terraformDestroy', false, 'terraform APPLY on above selected terraform plans')
    }
  definition {
    cps {
      script(readFileFromWorkspace('pipelines/splunk/puppet_master_destroy.groovy'))
      sandbox()
    }
  }
}
