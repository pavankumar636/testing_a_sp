pipelineJob('ciso-gsoc-splunk-Instance-Start') {
  description('This Pipeline is Used for Starting Splunk Non-Prod Environment Instances')
  logRotator(5, 5)
  triggers {
        cron('00 06 * * 1-5')
  }
  parameters {
    choiceParam('environment', ["nonprod"], '')
	stringParam('awsAccount','945457899050','Enter the account number')
    choiceParam('action', ['start'], '')
   	choiceParam('ApplyPlan', ['Yes','No'], 'Choose Yes for Implementing Changes')
     }
 definition {
   cps {
     script(readFileFromWorkspace('pipelines/splunk/Splunk_StartStop_Instance.groovy'))
	 sandbox()
    }
  }
}

pipelineJob('ciso-gsoc-splunk-Instance-Stop') {
  description('This Pipeline is Used for Stopping Splunk Non-Prod Environment Instances')
  logRotator(5, 5)
  triggers {
        cron('00 19 * * 1-5')
  }
  parameters {
    choiceParam('environment', ["nonprod"], '')
	stringParam('awsAccount','945457899050','Enter the account number')
    choiceParam('action', ['stop'], '')
    choiceParam('ApplyPlan', ['Yes','No'], 'Choose Yes for Implementing Changes')
     }
 definition {
   cps {
     script(readFileFromWorkspace('pipelines/splunk/Splunk_StartStop_Instance.groovy'))
	 sandbox()
    }
  }
}
