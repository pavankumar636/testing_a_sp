// Git repository holding terraform/packer scripts
def gitCreds             = 'bitbucket'
def gitBuildRepo         = 'https://stash.aviva.co.uk/scm/gcisoseceng/splunk-ami-v1-build.git'

def gitBranch      		 = 'develop'


// CISCAT profile and bencmark details
def cisArchive           = 'ciscat-full-bundle-2018-04-03-v3.0.46.zip'
def cisBenchmark         = 'benchmarks/CIS_Red_Hat_Enterprise_Linux_7_Benchmark_v2.1.1-xccdf.xml'
def cisProfile           = 'xccdf_org.cisecurity.benchmarks_profile_Level_2_-_Server'

// Environment specific parameters
def environment          = 'nonprod'
def managementAccount    = '906261169288'
def prodManagementAccount= '281077040066'
def cisoAccount          = '945457899050'
def prodCisoAccount      = '565933204446'

def accountsShare        = "${cisoAccount},${prodCisoAccount}"
def accountsEncrypt      = "${cisoAccount}"

def vaultAddress         = "https://vault.management.aws-euw1-np.avivacloud.com"

// Tags
def ownerTag = "splunkalerts@aviva.com"
def costCentreTag = "9V845"
def HsnTag = "SECURITY EVENT LOGGING NPE AWD"

// Applicaiton specific parameters
def packerDir            = 'packer'
def terraformDir         = 'terraform'
def terraformEnvironment = "${environment}"

pipelineJob('ciso-gsoc-splunk-server-ami-build') {
  description('Packer build of encrypted AMI for splunk')
  logRotator(5, 5)
  parameters {
    choiceParam('gitCreds', [gitCreds], '')
    choiceParam('gitUrl', [gitBuildRepo], '')
    stringParam('gitBranch', gitBranch, '')
    choiceParam('packerDir', [packerDir], '')
    choiceParam('packerTemplateFile', ['splunk.json','puppet-master.json'], '')
    choiceParam('packerVarFile', ['variables.json'], '')
	choiceParam('packerUserDataFile', ['user_data.yml'], '')
    choiceParam('packerLogLevel', ['0', '1'], '')
    choiceParam('managementAccount', [managementAccount], '')
    choiceParam('cisoAccount', [cisoAccount], '')
    stringParam('accountsShare', accountsShare, '')
    stringParam('accountsEncrypt', accountsEncrypt, '')
    stringParam('terraformEnvironment', terraformEnvironment, '')
    choiceParam('terraformDir', [terraformDir], '')
	choiceParam('terraformVarFile', ['terraform.tfvars'], '')
    choiceParam('terraformLogLevel', ['ERROR', 'WARN', 'INFO', 'DEBUG'], '')
    choiceParam('serverspecRole', ['test:all'], '')
    choiceParam('cisArchive', [cisArchive], '')
    choiceParam('cisBenchmark', [cisBenchmark], '')
    choiceParam('cisProfile', [cisProfile], '')
    choiceParam('deleteUnencryptedAmi', ['no', 'yes'], '')
	choiceParam('ownerTag', [ownerTag], '')
    choiceParam('costCentreTag', [costCentreTag], '')
    choiceParam('HsnTag', [HsnTag], '')
  }
  definition {
    cps {
      script(readFileFromWorkspace('pipelines/splunk/rhel_encrypted_app_build.groovy'))
	  sandbox()
    }
  }
}

// Build Pipeline
pipelineJob('ciso-gsoc-splunk-ami-snapshot-cleanup') {
  description('')
  logRotator(5, 5)
  parameters {
    choiceParam('awsAccount',['managementAccount',  'cisoAccount'],'')
    choiceParam('managementAccountID', ['906261169288'], '')
    choiceParam('clientAccountID', ['945457899050'], 'Choose any')
    choiceParam('deleteBy', ['AMI_ID', 'AMI_NAME', 'SNAP_ID'], 'Choose if you want to delete by specific AMI ID or by AMI Name or by SnapshotId')
    stringParam('amiID', '', 'Enter the AMI ID which needs to be deregistered from the chosen account')
    stringParam('snapID', '', 'Enter the SNAPSHOT ID which needs to be deleted from the chosen account')
    stringParam('AmiName', '', 'Enter the APP name until the environment e.g. splunk-test, populate if deletion to be done by AMI_NAME else leave empty')
    stringParam('latestAmiCount', '', 'Enter the number of latest AMIs which needs to be retained from the chosen account minimum=4, populate if deletion to be done by AMI_NAME else leave empty')
    stringParam('tagsFilter', '', 'Select the relevant environments HSN ex: SECURITY EVENT LOGGING NPE AWD, populate if deletion to be done by AMI_NAME else leave empty')

  }
  definition {
    cps {
      script(readFileFromWorkspace('pipelines/splunk/ami_delete.groovy'))
	  sandbox()
    }
  }
}
