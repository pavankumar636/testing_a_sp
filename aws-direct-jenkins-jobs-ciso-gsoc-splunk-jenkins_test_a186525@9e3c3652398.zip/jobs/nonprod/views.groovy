nestedView('CISO') {
  description('')
  views {
    nestedView('admin') {
      description('')
      views {
        listView('seedjobs') {
          description('')
          jobs {
            name ('admin-seedjob-ciso-gsoc-splunk')
          }
          columns {
            status()
            weather()
            name()
            lastSuccess()
            lastFailure()
            lastDuration()
            buildButton()
          }
        }
      }
    }
    nestedView('gsoc') {
      description('')
      views {
        listView('All') {
          description('')
          jobs {
            name ('admin-seedjob-ciso-gsoc-splunk')
            regex(/ciso-.*/)
          }
          columns {
            status()
            weather()
            name()
            lastSuccess()
            lastFailure()
            lastDuration()
            buildButton()
          }
        }
        listView('splunk') {
          description('')
          jobs {
            regex(/ciso-gsoc-splunk.*/)
          }
          columns {
            status()
            weather()
            name()
            lastSuccess()
            lastFailure()
            lastDuration()
            buildButton()
          }
        }
        listView('middleware') {
          description('')
          jobs {
            regex(/ciso-gsoc-splunk-sec-eng-middleware.*/)
          }
          columns {
            status()
            weather()
            name()
            lastSuccess()
            lastFailure()
            lastDuration()
            buildButton()
          }
        }
      }
    }
	nestedView('cyberark') {
      description('')
      views {
        listView('Seed Job') {
          description('')
          jobs {
            name ('admin-seedjob-ciso-cyberark')
           }
          columns {
            status()
            weather()
            name()
            lastSuccess()
            lastFailure()
            lastDuration()
            buildButton()
          }
        }
        listView('All Jobs') {
          description('')
          jobs {
            regex(/ciso-cyberark.*/)
          }
          columns {
            status()
            weather()
            name()
            lastSuccess()
            lastFailure()
            lastDuration()
            buildButton()
          }
        }
      }
    }
  }
}
