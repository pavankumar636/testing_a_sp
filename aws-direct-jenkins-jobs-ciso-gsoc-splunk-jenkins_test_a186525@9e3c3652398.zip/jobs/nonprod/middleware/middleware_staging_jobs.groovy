pipelineJob('ciso-gsoc-splunk-sec-eng-middleware-deploy') {
  description('Deploy Middleware')
  logRotator(5, 5)
  parameters {
    choiceParam('environment', ["nonprod"], '')
    choiceParam('action', ['create', 'destroy'], '')
    stringParam('gitBranch', 'master', 'Enter the Git branch to use')
    stringParam('infrastructure_prefix', '', 'Infrastructure Prefix (Optional)')
    booleanParam('terraformApplyPlan', false, 'Run Terraform Apply')
	choiceParam('approvers', ['rol_splunk_deployer_uknp'], '')
  }
  definition {
    cps {
      script(readFileFromWorkspace('pipelines/middleware/middleware_infrastructure_deploy.groovy'))
      sandbox()
    }
  }
}

