package testSupport

import com.lesfurets.jenkins.unit.RegressionTest
import spock.lang.Specification

/**
 * A base class for Spock testing using the pipeline helper
 */
class PipelineSpockTestBase extends Specification  implements RegressionTest {

    /**
     * Delegate to the test helper
     */
    @Delegate PipelineTestHelper pipelineTestHelper

    /**
     * Create and configure the helper
     */
    def setup() {
        pipelineTestHelper = new PipelineTestHelper()
        pipelineTestHelper.setUp()
    }
}
