package tests.library

import testSupport.PipelineSpockTestBase

class configDeployTestSpec extends PipelineSpockTestBase {

    def "test config_deploy"() {

        when:
            binding.setVariable('WORKSPACE', "fakevar")
            binding.setVariable('GIT_ASKPASS', "fakevar")
            binding.setVariable('gitBranch', "fakevar")
            binding.setVariable('gitCreds', "fakevar")
            binding.setVariable('gitUrl', "fakevar")

            binding.setVariable('terraformDir', "fakevar")
            binding.setVariable('terraformBucket', "fakevar")
            binding.setVariable('terraformKey', "fakevar")
            binding.setVariable('terraformApplyPlan', "fakevar")
            binding.setVariable('approvers', "fakevar")

            binding.setVariable('params', [
                    'gitModules':'this,that'
            ])
            runScript('pipelines/management/config_deploy.groovy')

        then:
            printCallStack()
            assertJobStatusSuccess()
    }
}
